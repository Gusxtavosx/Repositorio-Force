#!/usr/bin/env python3
"""Build Foundry release assets for a GitHub repository."""

import argparse
import json
from pathlib import Path
import re
from zipfile import ZIP_DEFLATED, ZipFile


ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository", required=True, help="GitHub owner/repository")
    parser.add_argument("--tag", required=True, help="Release tag, e.g. v0.6.0")
    parser.add_argument("--output", type=Path, default=ROOT / "dist")
    args = parser.parse_args()

    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", args.repository):
        parser.error("--repository must be in owner/repository format")

    manifest = json.loads((ROOT / "module.json").read_text(encoding="utf-8"))
    version = manifest["version"]
    if args.tag != f"v{version}":
        parser.error(f"tag {args.tag!r} differs from module version v{version}")

    base = f"https://github.com/{args.repository}"
    asset = f"{manifest['id']}-{args.tag}.zip"
    manifest.update(
        url=base,
        manifest=f"{base}/releases/latest/download/module.json",
        download=f"{base}/releases/download/{args.tag}/{asset}",
    )
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    (output / "module.json").write_bytes(manifest_bytes)

    # Foundry installs the files under Data/modules/<id>; module.json must be
    # at the archive root, not inside another directory.
    with ZipFile(output / asset, "w", compression=ZIP_DEFLATED) as archive:
        archive.writestr("module.json", manifest_bytes)
        for directory in ("scripts", "styles", "vendor"):
            for path in sorted((ROOT / directory).rglob("*")):
                if path.is_file():
                    archive.write(path, path.relative_to(ROOT).as_posix())
        archive.write(ROOT / "LEIA-ME.txt", "LEIA-ME.txt")

    print(f"Manifest: {output / 'module.json'}")
    print(f"Archive: {output / asset}")
    print(f"Foundry installation URL: {manifest['manifest']}")


if __name__ == "__main__":
    main()
