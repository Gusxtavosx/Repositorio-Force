import { registerGeminiControls } from "./gemini-inserts.js";

const MODULE_ID = "gemini-tinymce";
const ENGINE_ID = "tinymce";

function renderTinyMCE(config = {}) {
  const { editable = true, button = false } = config;
  const wrapper = document.createElement("div");
  wrapper.className = "editor gemini-tinymce-editor";

  const content = document.createElement("div");
  content.className = "editor-content";
  content.dataset.engine = ENGINE_ID;
  if (editable && config.name) content.dataset.edit = config.name;
  content.innerHTML = config.value ?? "";
  wrapper.append(content);

  if (editable && button) {
    const toggle = document.createElement("a");
    toggle.className = "editor-edit";
    toggle.innerHTML = '<i class="fa-solid fa-pen-to-square"></i>';
    wrapper.prepend(toggle);
  }
  return wrapper;
}

async function createTinyMCE(options = {}, content = "") {
  if (!globalThis.tinymce) {
    throw new Error(`${MODULE_ID}: biblioteca TinyMCE não carregada`);
  }

  const target = options.target;
  const fieldName = target?.dataset?.edit ?? options.name;

  async function save(instance) {
    const windows = Object.values(globalThis.ui?.windows ?? {});
    const sheet = windows.find(app => app.editors?.[fieldName]?.instance === instance)
      ?? windows.find(app => app.form?.contains(target) && typeof app.saveEditor === "function")
      ?? options.document?.sheet;
    const document = sheet?.document ?? sheet?.object ?? options.document;

    if (!fieldName || !fieldName.startsWith("system.") || typeof document?.update !== "function") {
      const message = `${MODULE_ID}: não foi possível identificar o campo ou documento para salvar`;
      console.error(message, { fieldName, sheet, document });
      globalThis.ui?.notifications?.error(message);
      return;
    }

    try {
      const html = instance.getContent();
      await document.update({ [fieldName]: html });
      const saved = globalThis.foundry?.utils?.getProperty(document, fieldName);
      if (saved !== html) {
        throw new Error(`O campo ${fieldName} não corresponde ao conteúdo enviado após update`);
      }
      instance.setDirty?.(false);
      globalThis.ui?.notifications?.info("Descrição salva na ficha.");
    } catch (error) {
      console.error(`${MODULE_ID}: falha ao salvar ${fieldName}`, error);
      globalThis.ui?.notifications?.error("Gemini TinyMCE: não foi possível salvar a descrição.");
    }
  }

  const [editor] = await globalThis.tinymce.init({
    target: options.target,
    base_url: `/modules/${MODULE_ID}/vendor/tinymce`,
    suffix: ".min",
    skin: "oxide-dark",
    content_css: "dark",
    branding: false,
    promotion: false,
    menubar: false,
    statusbar: false,
    resize: false,
    height: options.height ?? 350,
    plugins: "advlist lists link image table code fullscreen searchreplace visualblocks wordcount",
    toolbar_mode: "sliding",
    toolbar: "geminiSave | undo redo | blocks | geminiTools | alignleft aligncenter alignright alignjustify | table | code fullscreen",
    convert_urls: false,
    extended_valid_elements: "span[*],div[*],section[*],article[*],header[*],footer[*],a[*]",
    content_style: "html,body{background:#202127!important;color:#f3f4f7!important}body{padding:10px;line-height:1.5}table{border-collapse:collapse;width:100%}td,th{border:1px solid #777;padding:5px}.gemini-box{border-left:4px solid #8053ba;background:#f3eefb;padding:12px;margin:12px 0;color:#202027}.gemini-box--rule{border-left-color:#366da3;background:#edf4fa}.gemini-box--master{border-left-color:#a76927;background:#fbf2e8}.gemini-condition{color:#ffb184}",
    setup(instance) {
      instance.ui.registry.addButton("geminiSave", {
        text: "Salvar",
        tooltip: "Salvar descrição na ficha",
        onAction: () => save(instance)
      });
      instance.addShortcut("meta+s", "Salvar descrição", () => save(instance));
      registerGeminiControls(instance, { fieldName, document: options.document });
    }
  });

  if (!editor) throw new Error(`${MODULE_ID}: falha ao iniciar o editor`);
  editor.document = options.document;
  // A ficha Mythras passa HTML já enriquecido em {{editor}}. Carregar o valor
  // bruto do documento evita salvar números renderizados no lugar de {{...}}.
  const sheet = Object.values(globalThis.ui?.windows ?? {})
    .find(app => app.form?.contains(target));
  const document = sheet?.document ?? sheet?.object ?? options.document;
  const raw = fieldName && globalThis.foundry?.utils?.getProperty(document, fieldName);
  if (typeof raw === "string") editor.setContent(raw);
  else if (content) editor.setContent(content);
  return editor;
}

Hooks.once("init", () => {
  CONFIG.TextEditor.engines[ENGINE_ID] = {
    create: createTinyMCE,
    render: renderTinyMCE
  };
});

// Alguns templates passam as opções pelo hash do Handlebars; outros as passam
// diretamente ao helper. Indicamos a engine em ambos os formatos.
Hooks.once("ready", () => {
  const original = Handlebars.helpers.editor;
  if (typeof original !== "function") {
    console.warn(`${MODULE_ID}: helper {{editor}} não encontrado; use engine="tinymce" nos templates.`);
    return;
  }
  Handlebars.registerHelper("editor", function (content, options) {
    if (!options || (options.hash?.engine && options.hash.engine !== "prosemirror") ||
        (options.engine && options.engine !== "prosemirror")) {
      return original.apply(this, arguments);
    }
    return original.call(this, content, {
      ...options,
      engine: ENGINE_ID,
      hash: { ...options.hash, engine: ENGINE_ID }
    });
  });
  console.log(`${MODULE_ID}: TinyMCE ${globalThis.tinymce?.majorVersion ?? "?"} registrado`);
});

// Complemento para fichas legadas que já renderizaram seu HTML antes do
// registro do helper ou usam uma implementação própria de {{editor}}.
function selectTinyMCEInSheet(app, html) {
  const root = html?.[0] ?? html;
  if (!root?.querySelectorAll) return;
  let updated = 0;
  for (const content of root.querySelectorAll(".editor .editor-content")) {
    if (content.dataset.engine && !["prosemirror", ENGINE_ID].includes(content.dataset.engine)) continue;
    if (content.dataset.engine !== ENGINE_ID) {
      content.dataset.engine = ENGINE_ID;
      updated++;
    }
    const name = content.dataset.edit;
    const editor = name && app.editors?.[name];
    if (editor && !editor.instance && editor.options) editor.options.engine = ENGINE_ID;
  }
  if (updated) console.info(`${MODULE_ID}: ${updated} campo(s) da ficha preparados para TinyMCE`);
}

Hooks.on("renderActorSheet", selectTinyMCEInSheet);
Hooks.on("renderItemSheet", selectTinyMCEInSheet);

// Fluxo de salvamento de fichas legadas (ApplicationV1), conforme a API v14.
Hooks.on("activateEditorLegacy", (editor, options) => {
  if (options.engine !== ENGINE_ID || !editor.instance) return;
  editor.instance.focus();
  editor.instance.on("change input undo redo", () => { editor.changed = true; });
});

Hooks.on("renderFormApplication", app => {
  app.form?.addEventListener("formdata", event => {
    for (const [name, editor] of Object.entries(app.editors ?? {})) {
      if (!editor.instance || editor.options?.engine !== ENGINE_ID) continue;
      const content = editor.instance.getContent();
      if (editor.mce?.id) event.formData.delete(editor.mce.id);
      event.formData.set(name, content);
    }
  });
});
