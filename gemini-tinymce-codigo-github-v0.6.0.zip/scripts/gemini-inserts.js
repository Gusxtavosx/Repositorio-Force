const CHARACTERISTICS = [
  ["FOR (STR)", "str", "STR"], ["CON", "con", "CON"],
  ["TAM (SIZ)", "siz", "SIZ"], ["DES (DEX)", "dex", "DEX"],
  ["INT", "int", "INT"], ["POD (POW)", "pow", "POW"],
  ["CAR (CHA)", "cha", "CHA"]
];
const SKILL_TYPES = new Set(["standardSkill", "professionalSkill", "combatStyle", "magicSkill", "passion"]);

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, character => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[character]);
}

function ask(editor, title, fields, action) {
  editor.windowManager.open({
    title,
    body: {
      type: "panel",
      items: fields.map(({ name, label }) => ({ type: "input", name, label }))
    },
    initialData: Object.fromEntries(fields.map(({ name, value = "" }) => [name, value])),
    buttons: [
      { type: "cancel", text: "Cancelar" },
      { type: "submit", text: "Inserir", primary: true }
    ],
    onSubmit(api) {
      const data = api.getData();
      api.close();
      action(data);
    }
  });
}

export function registerGeminiControls(editor, context = {}) {
  const registry = editor.ui.registry;
  const templateField = ["system.abilitiesDesc", "system.gemini.specializations"].includes(context.fieldName);
  const notify = message => globalThis.ui?.notifications?.warn(message);
  const insertText = value => editor.insertContent(escapeHTML(value));

  function actor() {
    const windows = Object.values(globalThis.ui?.windows ?? {});
    const sheet = windows.find(app => app.editors?.[context.fieldName]?.instance === editor);
    const document = context.document ?? sheet?.document ?? sheet?.object;
    if (document?.documentName === "Actor") return document;
    return document?.parent?.documentName === "Actor" ? document.parent : sheet?.actor;
  }

  function needsTemplate() {
    if (templateField) return true;
    notify("Menções dinâmicas funcionam nos campos Habilidades e Especializações do ator.");
    return false;
  }

  function insertCharacteristic(characteristic, withRoll = false) {
    if (!needsTemplate()) return;
    const [label, key, color] = characteristic;
    const macro = `[[${color}:{{actor.characteristics.${key}}}]]`;
    insertText(withRoll ? `${label}: ${macro} — [[/r 1d100]]{Teste de ${label}}` : macro);
  }

  function skillItems() {
    return Array.from(actor()?.items ?? [])
      .filter(item => SKILL_TYPES.has(item.type))
      .sort((a, b) => a.name.localeCompare(b.name, "pt-BR"));
  }

  function insertSkill(skill, withRoll = false) {
    if (!needsTemplate()) return;
    if (!SKILL_TYPES.has(skill.type) || !/^[a-zA-Z0-9]+$/.test(skill.id)) {
      notify("Esta perícia não tem um identificador válido para o modelo.");
      return;
    }
    const lookup = `{{#each actor.itemTypes.${skill.type}}}{{#if (eq id "${skill.id}")}}`;
    const ending = "{{/if}}{{/each}}";
    const label = skill.name.replace(/[{}\[\]]/g, "");
    const result = `${lookup}${label}: [[cyan:{{totalVal}}]]%${ending}`;
    insertText(withRoll ? `${result} — [[/r 1d100]]{Teste de ${label}}` : result);
  }

  function chooseCharacteristic(withRoll) {
    return CHARACTERISTICS.map(characteristic => ({
      type: "menuitem", text: characteristic[0],
      onAction: () => insertCharacteristic(characteristic, withRoll)
    }));
  }

  function chooseSkill(withRoll) {
    const skills = skillItems();
    if (!skills.length) return [{ type: "menuitem", text: "Nenhuma perícia encontrada", onAction: () => notify("Abra a ficha de um ator com perícias.") }];
    return skills.map(skill => ({ type: "menuitem", text: skill.name, onAction: () => insertSkill(skill, withRoll) }));
  }

  function insertRoll(defaultFormula = "1d100", defaultLabel = "Rolagem") {
    ask(editor, "Rolagem", [
      { name: "formula", label: "Fórmula", value: defaultFormula },
      { name: "label", label: "Rótulo", value: defaultLabel }
    ], ({ formula, label }) => {
      const cleanFormula = String(formula ?? "").trim();
      if (!cleanFormula || cleanFormula.length > 200 || cleanFormula.includes("]]")) return notify("Informe uma fórmula válida.");
      insertText(`[[/r ${cleanFormula}]]{${String(label || "Rolagem").replace(/[{}]/g, "")}}`);
    });
  }

  function insertUUID(uuid = "", label = "") {
    ask(editor, "Link UUID", [
      { name: "uuid", label: "UUID", value: uuid },
      { name: "label", label: "Texto do link", value: label }
    ], data => {
      const id = String(data.uuid ?? "").trim();
      if (!/^[\w.-]+$/.test(id)) return notify("Informe um UUID do Foundry válido.");
      insertText(`@UUID[${id}]{${String(data.label || id).replace(/[{}]/g, "")}}`);
    });
  }

  function itemLinks() {
    const items = Array.from(actor()?.items ?? []).sort((a, b) => a.name.localeCompare(b.name, "pt-BR"));
    return [
      ...items.map(item => ({
        type: "menuitem", text: item.name,
        onAction: () => insertText(`@UUID[${item.uuid}]{${item.name.replace(/[{}]/g, "")}}`)
      })),
      { type: "menuitem", text: "Outro UUID...", onAction: () => insertUUID() }
    ];
  }

  function insertBox(kind = "gemini", title = "Box Gemini") {
    if (kind === "master") notify("Nota visual: o dono da ficha também poderá ler este texto. Não é uma permissão exclusiva do mestre.");
    const selected = editor.selection.getContent({ format: "text" }) || "Escreva aqui.";
    const modifier = kind === "gemini" ? "" : ` gemini-box--${kind}`;
    editor.insertContent(`<div class="gemini-box${modifier}"><strong>${escapeHTML(title)}</strong><p>${escapeHTML(selected)}</p></div>`);
  }

  function insertPower() {
    ask(editor, "Poder", [{ name: "name", label: "Nome do poder", value: "Poder" }],
      data => insertBox("gemini", String(data.name || "Poder")));
  }

  function insertCondition() {
    ask(editor, "Condição", [{ name: "name", label: "Nome da condição", value: "Condição" }], data => {
      notify("Este atalho insere um marcador no texto; ele não aplica uma condição ao ator.");
      editor.insertContent(`<strong class="gemini-condition">${escapeHTML(data.name || "Condição")}</strong>`);
    });
  }

  registry.addMenuButton("geminiCharacteristic", { text: "Característica", fetch: callback => callback(chooseCharacteristic(false)) });
  registry.addMenuButton("geminiSkill", { text: "Perícia", fetch: callback => callback(chooseSkill(false)) });
  registry.addButton("geminiDamage", { text: "Dano", onAction: () => insertRoll("1d10", "Dano") });
  registry.addButton("geminiTest", { text: "Teste", onAction: () => insertRoll("1d100", "Teste") });
  registry.addButton("geminiRoll", { text: "Rolagem", onAction: () => insertRoll() });
  registry.addButton("geminiUUID", { text: "UUID", onAction: () => insertUUID() });
  registry.addButton("geminiBox", { text: "Box Gemini", onAction: () => insertBox() });
  registry.addButton("geminiMasterNote", { text: "Nota do Mestre", onAction: () => insertBox("master", "Nota do Mestre") });

  registry.addNestedMenuItem("geminiCharacteristicTest", { text: "Teste de Característica", getSubmenuItems: () => chooseCharacteristic(true) });
  registry.addNestedMenuItem("geminiSkillTest", { text: "Teste de Perícia", getSubmenuItems: () => chooseSkill(true) });
  registry.addMenuItem("geminiRollMenu", { text: "Rolagem", onAction: () => insertRoll() });
  registry.addNestedMenuItem("geminiItemLink", { text: "Link de Item", getSubmenuItems: itemLinks });
  registry.addMenuItem("geminiPowerMenu", { text: "Poder", onAction: insertPower });
  registry.addMenuItem("geminiConditionMenu", { text: "Condição", onAction: insertCondition });
  registry.addMenuItem("geminiRuleBoxMenu", { text: "Caixa de Regra", onAction: () => insertBox("rule", "Regra") });

  // Uma única entrada visível reúne todos os atalhos anteriores.
  registry.addMenuButton("geminiTools", {
    text: "Inserir",
    tooltip: "Atalhos do Gemini",
    fetch(callback) {
      callback([
        { type: "nestedmenuitem", text: "Característica", getSubmenuItems: () => chooseCharacteristic(false) },
        { type: "nestedmenuitem", text: "Perícia", getSubmenuItems: () => chooseSkill(false) },
        { type: "menuitem", text: "Dano", onAction: () => insertRoll("1d10", "Dano") },
        { type: "menuitem", text: "Teste", onAction: () => insertRoll("1d100", "Teste") },
        { type: "menuitem", text: "Rolagem", onAction: () => insertRoll() },
        { type: "menuitem", text: "UUID", onAction: () => insertUUID() },
        { type: "menuitem", text: "Box Gemini", onAction: () => insertBox() },
        { type: "menuitem", text: "Nota do Mestre", onAction: () => insertBox("master", "Nota do Mestre") },
        { type: "nestedmenuitem", text: "Teste de Característica", getSubmenuItems: () => chooseCharacteristic(true) },
        { type: "nestedmenuitem", text: "Teste de Perícia", getSubmenuItems: () => chooseSkill(true) },
        { type: "nestedmenuitem", text: "Link de Item", getSubmenuItems: itemLinks },
        { type: "menuitem", text: "Poder", onAction: insertPower },
        { type: "menuitem", text: "Condição", onAction: insertCondition },
        { type: "menuitem", text: "Caixa de Regra", onAction: () => insertBox("rule", "Regra") }
      ]);
    }
  });
}
