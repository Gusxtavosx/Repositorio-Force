import { Marked } from "../vendor/marked.esm.js";

const MODULE_ID = "gemini-contacts";
const FLAG = "entries";
const CATALOG_FLAG = "catalog";
const SOCIAL_TABS = new Map();
const KINDS = Object.freeze({
  contact: "Contato",
  instructor: "Instrutor",
  support: "Retaguarda"
});

const escapeHTML = value => String(value ?? "").replace(/[&<>"']/g, character => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
})[character]);

function safeLink(value) {
  const href = String(value ?? "").trim();
  if (/^(?:https?:\/\/|mailto:)[^<>"'\\\x00-\x1F]+$/i.test(href)) return href;
  if (/^(?!\/\/)(?![a-z][a-z\d+.-]*:)[^<>"'\\\x00-\x1F]+$/i.test(href)) return href;
  return "#";
}

const markdown = new Marked({
  gfm: true,
  breaks: true,
  renderer: {
    html: token => escapeHTML(token.text),
    link(token) {
      const label = this.parser.parseInline(token.tokens);
      return `<a href="${escapeHTML(safeLink(token.href))}">${label}</a>`;
    },
    image: token => `<img src="${escapeHTML(safeImage(token.href))}" alt="${escapeHTML(token.text)}">`
  }
});

function descriptionHTML(value, format) {
  return foundry.utils.cleanHTML(format === "html" ? String(value ?? "") : markdown.parse(String(value ?? "")));
}

async function renderDescription(value, format, target, actor) {
  if (!value?.trim()) {
    target.textContent = "Sem anotações.";
    return;
  }
  target.innerHTML = await foundry.applications.ux.TextEditor.implementation.enrichHTML(descriptionHTML(value, format), {
    relativeTo: actor, secrets: game.user.isGM
  });
}

function safeImage(value) {
  const path = String(value ?? "").trim();
  if (/^https?:\/\/[^<>"'\\\x00-\x1F]+$/i.test(path)) return path;
  if (/^(?!\/\/)(?![a-z][a-z\d+.-]*:)[^<>"'\\\x00-\x1F]+$/i.test(path)) return path;
  return "icons/svg/mystery-man.svg";
}

function normalizeEntry(data) {
  const kind = Object.hasOwn(KINDS, data.kind) ? data.kind : "contact";
  const friendship = Number(data.friendship);
  return {
    id: String(data.id || foundry.utils.randomID()),
    name: String(data.name || "").trim().slice(0, 120),
    image: safeImage(data.image),
    kind,
    group: String(data.group || "").trim().slice(0, 100),
    friendship: kind === "contact" ? Math.max(1, Math.min(100,
      Number.isFinite(friendship) ? Math.round(friendship) : 1)) : null,
    role: kind === "support" ? String(data.role || "").trim().slice(0, 100) : "",
    description: String(data.description || "").slice(0, 50000),
    format: data.format === "html" ? "html" : "markdown",
    sourceUuid: String(data.sourceUuid || "")
  };
}

function getEntries(actor) {
  const saved = actor.getFlag(MODULE_ID, FLAG);
  return Array.isArray(saved) ? saved.filter(row => row && typeof row === "object").map(normalizeEntry) : [];
}

function canEdit(actor) {
  return Boolean(game.user?.isGM && actor.canUserModify(game.user, "update"));
}

async function storeEntries(actor, entries) {
  if (!canEdit(actor)) throw new Error("Apenas um mestre com permissão na ficha pode configurar contatos.");
  await actor.setFlag(MODULE_ID, FLAG, entries.map(normalizeEntry));
}

function make(tag, className, text) {
  const element = document.createElement(tag);
  element.className = className;
  if (text != null) element.textContent = text;
  return element;
}

function caption(entry) {
  if (entry.kind === "contact") return `Amizade: ${entry.friendship}%`;
  if (entry.kind === "support") return entry.role || "Retaguarda";
  return KINDS[entry.kind];
}

function paint(section, actor) {
  const grid = section.querySelector(".gemini-contacts-grid");
  const support = section.querySelector(".gemini-contacts-support");
  const supportGrid = section.querySelector(".gemini-contacts-support-grid");
  grid.replaceChildren();
  supportGrid.replaceChildren();
  const entries = getEntries(actor);
  support.hidden = !entries.some(entry => entry.kind === "support");
  if (!entries.length) {
    grid.append(make("p", "gemini-contacts-empty", "Nenhum contato cadastrado."));
    return;
  }
  for (const entry of entries) {
    const wrapper = make("div", "gemini-contact-wrapper");
    const card = make("button", `gemini-contact-card gemini-contact-${entry.kind}`);
    card.type = "button";
    card.draggable = canEdit(actor);
    card.title = canEdit(actor) ? `Editar ${entry.name}` : `Ver ${entry.name}`;
    card.append(make("strong", "gemini-contact-name", entry.name));
    const portrait = make("img", "gemini-contact-image");
    portrait.src = safeImage(entry.image);
    portrait.alt = "";
    portrait.loading = "lazy";
    card.append(portrait, make("span", "gemini-contact-badge", caption(entry)));
    card.addEventListener("click", event => {
      event.preventDefault();
      event.stopPropagation();
      void openEntry(actor, entry).catch(reportError);
    });
    if (canEdit(actor)) card.addEventListener("dragstart", event => {
      event.dataTransfer.setData("text/plain", JSON.stringify({
        type: "GeminiContact", sourceActorUuid: actor.uuid, id: entry.id
      }));
      event.dataTransfer.effectAllowed = "copy";
    });
    wrapper.append(card);
    if (canEdit(actor)) {
      const remove = make("button", "gemini-contact-delete", "×");
      remove.type = "button";
      remove.title = `Excluir ${entry.name}`;
      remove.setAttribute("aria-label", `Excluir ${entry.name}`);
      remove.addEventListener("click", event => {
        event.preventDefault();
        event.stopPropagation();
        void deleteEntry(actor, entry).catch(reportError);
      });
      wrapper.append(remove);
    }
    (entry.kind === "support" ? supportGrid : grid).append(wrapper);
  }
}

function reportError(error) {
  console.error(`[${MODULE_ID}]`, error);
  ui.notifications.error(`Contatos: ${error.message || error}`);
}

function buildForm(entry = {}) {
  const kind = Object.hasOwn(KINDS, entry.kind) ? entry.kind : "contact";
  const root = make("div", "gemini-contacts-form");
  root.innerHTML = `
    <div class="gemini-contacts-eyebrow"><span class="gemini-contacts-indicator"></span> GEMINI FORCE <span class="gemini-contacts-eyebrow-end">ARQUIVO SOCIAL</span></div>
    <div class="gemini-contacts-hero">
      <div class="gemini-contacts-portrait">
        <img class="gemini-contacts-preview" src="${escapeHTML(safeImage(entry.image))}" alt="Imagem do contato">
        <div class="gemini-contacts-portrait-label">PERFIL</div>
      </div>
      <div class="gemini-contacts-hero-fields">
        <div class="gemini-contacts-card-heading">IDENTIDADE <span>01 / 02</span></div>
        <label>Nome <input name="name" type="text" maxlength="120" required value="${escapeHTML(entry.name || "")}" placeholder="Nome do NPC"></label>
        <label>Categoria <select name="kind">${Object.entries(KINDS).map(([value, label]) =>
          `<option value="${value}" ${value === kind ? "selected" : ""}>${label}</option>`).join("")}</select></label>
        <label>Grupo (opcional) <input name="group" type="text" maxlength="100" value="${escapeHTML(entry.group || "")}" placeholder="Ex.: DRACS, CCN, Gemini City"></label>
        <label data-when="contact">Amizade (%) <input name="friendship" type="number" min="1" max="100" step="1" value="${Number(entry.friendship) || 1}"></label>
        <label data-when="support">Cargo/posto na retaguarda <input name="role" type="text" maxlength="100" value="${escapeHTML(entry.role || "")}" placeholder="Ex.: Analista, médica, logística"></label>
        <label>Imagem/ícone <span class="gemini-contacts-image-field"><input name="image" type="text" value="${escapeHTML(entry.image || "")}" placeholder="Caminho ou URL da imagem"><button type="button" data-pick-image title="Escolher imagem"><i class="fas fa-image"></i></button></span></label>
      </div>
    </div>
    <div class="gemini-contacts-description-panel">
      <div class="gemini-contacts-card-heading">DESCRIÇÃO E SISTEMÁTICA <span>02 / 02</span></div>
      <div class="gemini-contacts-markdown-fallback">
        <div class="gemini-contacts-markdown-tabs">
          <button type="button" class="active" data-markdown-tab="write">Escrever</button>
          <button type="button" data-markdown-tab="preview">Prévia</button>
        </div>
        <div class="gemini-contacts-markdown-toolbar">
          <button type="button" data-markdown-insert="bold" title="Negrito">B</button>
          <button type="button" data-markdown-insert="italic" title="Itálico"><i>I</i></button>
          <button type="button" data-markdown-insert="heading" title="Título">H</button>
          <button type="button" data-markdown-insert="list" title="Lista">≡</button>
        </div>
      </div>
      <textarea name="description" rows="10" maxlength="50000" placeholder="Escreva sobre o NPC, funções, benefícios e regras...">${escapeHTML(entry.description || "")}</textarea>
      <div class="gemini-contacts-markdown-preview" hidden></div>
      <div class="gemini-contacts-editor-hint">${entry.format === "html" ? "Conteúdo formatado em HTML." : "O editor TinyMCE abrirá aqui quando o módulo Gemini TinyMCE estiver ativo."}</div>
    </div>
  `;
  const content = document.createElement("div");
  content.append(root);
  return content;
}

function insertMarkdown(textarea, type) {
  const start = textarea.selectionStart;
  const end = textarea.selectionEnd;
  const selection = textarea.value.slice(start, end);
  let insert;
  let selectFrom;
  if (type === "heading" || type === "list") {
    const prefix = type === "heading" ? "## " : "- ";
    insert = `${start > 0 && textarea.value[start - 1] !== "\n" ? "\n" : ""}${prefix}${selection || "Texto"}`;
    selectFrom = start + insert.length - (selection || "Texto").length;
  } else {
    const marker = type === "bold" ? "**" : "*";
    insert = `${marker}${selection || "texto"}${marker}`;
    selectFrom = start + marker.length;
  }
  textarea.setRangeText(insert, start, end, "end");
  textarea.focus();
  textarea.setSelectionRange(selectFrom, selectFrom + (selection || (type === "heading" || type === "list" ? "Texto" : "texto")).length);
  textarea.dispatchEvent(new Event("input", { bubbles: true }));
}

async function initializeTinyMCE(dialog, textarea, entry) {
  const initialHTML = descriptionHTML(entry.description, entry.format);
  try {
    const [instance] = await globalThis.tinymce.init({
      target: textarea,
      base_url: "/modules/gemini-tinymce/vendor/tinymce",
      suffix: ".min",
      skin: "oxide-dark",
      content_css: "dark",
      content_style: "html,body{background:#1a1b25!important;color:#f3f4f7!important}body{padding:12px;line-height:1.55}table{border-collapse:collapse;width:100%}td,th{border:1px solid #777;padding:5px}",
      branding: false,
      promotion: false,
      menubar: false,
      statusbar: false,
      resize: false,
      height: 260,
      plugins: "table",
      toolbar_mode: "sliding",
      toolbar: "geminiContactSave | alignleft aligncenter alignright alignjustify | table",
      convert_urls: false,
      setup(instance) {
        const save = () => {
          const button = dialog.element?.querySelector('button[data-action="save"]')
            ?? Array.from(dialog.element?.querySelectorAll("button") || [])
              .find(candidate => candidate.textContent.trim() === "Salvar");
          if (button) button.click();
          else ui.notifications.error("Não foi possível localizar o botão Salvar do contato.");
        };
        instance.ui.registry.addButton("geminiContactSave", {
          text: "Salvar", tooltip: "Salvar contato e descrição", onAction: save
        });
        instance.addShortcut("meta+s", "Salvar contato", save);
      }
    });
    if (!instance) throw new Error("TinyMCE não iniciou.");
    if (!textarea.isConnected) {
      instance.remove();
      return null;
    }
    instance.setContent(initialHTML);
    dialog._geminiContactsEditor = instance;
    dialog.element.querySelector(".gemini-contacts-markdown-fallback").hidden = true;
    dialog.element.querySelector(".gemini-contacts-editor-hint").textContent = "Editor TinyMCE — salve o contato pelo botão abaixo.";
    return instance;
  } catch (error) {
    console.error(`[${MODULE_ID}] Falha ao iniciar TinyMCE; edição em texto mantida.`, error);
    textarea.style.display = "";
    return null;
  }
}

function bindForm(dialog, actor, previous) {
  const root = dialog.element.querySelector(".gemini-contacts-form");
  const kind = root.querySelector('[name="kind"]');
  const image = root.querySelector('[name="image"]');
  const preview = root.querySelector(".gemini-contacts-preview");
  const sync = () => {
    for (const row of root.querySelectorAll("[data-when]")) {
      row.hidden = row.dataset.when !== kind.value;
    }
  };
  kind.addEventListener("change", sync);
  image.addEventListener("input", () => { preview.src = safeImage(image.value); });
  root.querySelector("[data-pick-image]").addEventListener("click", () => {
    const Picker = foundry.applications.apps.FilePicker;
    void new Picker({ type: "image", current: image.value, callback: path => {
      image.value = path;
      preview.src = safeImage(path);
    }}).browse(image.value);
  });
  const textarea = root.querySelector('[name="description"]');
  const markdownPreview = root.querySelector(".gemini-contacts-markdown-preview");
  for (const button of root.querySelectorAll("[data-markdown-insert]")) {
    button.addEventListener("click", () => insertMarkdown(textarea, button.dataset.markdownInsert));
  }
  for (const button of root.querySelectorAll("[data-markdown-tab]")) {
    button.addEventListener("click", () => {
      const showPreview = button.dataset.markdownTab === "preview";
      textarea.hidden = showPreview;
      root.querySelector(".gemini-contacts-markdown-toolbar").hidden = showPreview;
      markdownPreview.hidden = !showPreview;
      for (const tab of root.querySelectorAll("[data-markdown-tab]")) {
        tab.classList.toggle("active", tab === button);
      }
      if (showPreview) void renderDescription(textarea.value, previous?.format, markdownPreview, actor).catch(reportError);
    });
  }
  if (game.modules.get("gemini-tinymce")?.active && globalThis.tinymce) {
    dialog._geminiContactsEditorReady = initializeTinyMCE(dialog, textarea, previous || {});
  }
  sync();
}

async function readForm(dialog, previous = {}) {
  if (dialog._geminiContactsEditorReady) await dialog._geminiContactsEditorReady;
  const root = dialog.element.querySelector(".gemini-contacts-form");
  const field = name => root.querySelector(`[name="${name}"]`).value;
  const editor = dialog._geminiContactsEditor;
  return normalizeEntry({
    ...previous, name: field("name"), kind: field("kind"), group: field("group"), image: field("image"),
    friendship: field("friendship"), role: field("role"),
    description: editor ? editor.getContent() : field("description"),
    format: editor ? "html" : previous.format || "markdown"
  });
}

async function promptEntry(previous = null, actor = null) {
  const Dialog = foundry.applications.api.DialogV2;
  const result = await Dialog.wait({
    classes: ["gemini-contacts-dialog"],
    position: { width: 700 },
    window: { title: previous ? `Editar ${previous.name}` : "Adicionar contato" },
    content: buildForm(previous || {}),
    render: (_event, dialog) => bindForm(dialog, actor, previous),
    close: (_event, dialog) => dialog._geminiContactsEditor?.remove(),
    buttons: [
      { action: "cancel", label: "Cancelar" },
      { action: "save", label: "Salvar", default: true, type: "submit",
        callback: (_event, _button, dialog) => readForm(dialog, previous || {}) }
    ]
  });
  if (!result || result === "cancel") return null;
  if (!result.name) {
    ui.notifications.warn("Digite o nome do contato antes de salvar.");
    return null;
  }
  return result;
}

async function editEntry(actor, previous = null) {
  if (!canEdit(actor)) return;
  const result = await promptEntry(previous, actor);
  if (!result) return;
  const entries = getEntries(actor);
  const index = previous ? entries.findIndex(row => row.id === previous.id) : -1;
  if (index >= 0) entries[index] = result;
  else entries.push(result);
  await storeEntries(actor, entries);
}

async function openEntry(actor, entry) {
  if (canEdit(actor)) {
    await editEntry(actor, entry);
    return;
  }
  const content = document.createElement("div");
  const view = make("div", "gemini-contacts-view");
  const hero = make("div", "gemini-contacts-view-hero");
  const image = make("img", "gemini-contacts-view-image");
  image.src = safeImage(entry.image);
  image.alt = entry.name;
  const info = make("div", "gemini-contacts-view-info");
  info.append(make("span", "gemini-contacts-view-kicker", "GEMINI FORCE / ARQUIVO SOCIAL"),
    make("h2", "gemini-contacts-view-name", entry.name),
    make("span", "gemini-contacts-view-category", KINDS[entry.kind]));
  if (entry.kind !== "instructor") info.append(make("strong", "gemini-contacts-view-type", caption(entry)));
  hero.append(image, info);
  view.append(hero, make("h3", "gemini-contacts-view-heading", "DESCRIÇÃO E SISTEMÁTICA"));
  const description = make("div", "gemini-contacts-view-description");
  await renderDescription(entry.description, entry.format, description, actor);
  view.append(description);
  content.append(view);
  await foundry.applications.api.DialogV2.prompt({
    classes: ["gemini-contacts-dialog"],
    position: { width: 700 },
    window: { title: entry.name }, content, ok: { label: "Fechar" }
  });
}

async function deleteEntry(actor, entry) {
  if (!canEdit(actor)) return;
  const confirmed = await foundry.applications.api.DialogV2.confirm({
    classes: ["gemini-contacts-dialog"],
    window: { title: "Excluir contato" },
    content: `<p>Excluir <strong>${escapeHTML(entry.name)}</strong> desta ficha?</p>`
  });
  if (confirmed) await storeEntries(actor, getEntries(actor).filter(row => row.id !== entry.id));
}

function cloneEntry(entry) {
  return normalizeEntry({ ...entry, id: foundry.utils.randomID() });
}

async function entryFromDrag(data) {
  if (!game.user.isGM) throw new Error("Apenas mestres podem conceder contatos.");
  if (data.type === "GeminiContact") {
    const source = await fromUuid(data.sourceActorUuid);
    if (source?.documentName !== "Actor" || !source.testUserPermission(game.user, "OWNER")) {
      throw new Error("A ficha de origem não está disponível.");
    }
    return getEntries(source).find(entry => entry.id === data.id);
  }
  if (data.type === "GeminiContactCatalog") {
    const catalog = await fromUuid(data.catalogUuid);
    if (catalog?.documentName !== "JournalEntry" || !catalog.getFlag(MODULE_ID, "isCatalog")) {
      throw new Error("O catálogo de contatos não está disponível.");
    }
    return getCatalogEntries(catalog).find(entry => entry.id === data.id);
  }
  return null;
}

async function copyToActor(actor, data) {
  if (!canEdit(actor)) return;
  if (data.type === "GeminiContact" && data.sourceActorUuid === actor.uuid) return;
  const entry = await entryFromDrag(data);
  if (!entry) throw new Error("O contato arrastado não foi encontrado.");
  await storeEntries(actor, [...getEntries(actor), cloneEntry(entry)]);
  ui.notifications.info(`${entry.name} foi copiado para ${actor.name}.`);
}

function install(actor, root) {
  if (game.system.id !== "mythras" || actor.type !== "character") return;
  if (!actor.testUserPermission(game.user, "OBSERVER")) return;
  if (!root.matches(".char-sheet") && !root.querySelector(".char-sheet")) return;
  const social = root.querySelector('.actor-sheet-tab.social[data-group="primary"][data-tab="social"]');
  if (!social || social.querySelector(".gemini-contacts")) return;
  const nav = make("nav", "gemini-social-nav");
  const socialButton = make("button", "gemini-social-tab");
  const contactsButton = make("button", "gemini-social-tab");
  socialButton.innerHTML = '<i class="fa-solid fa-people-group" aria-hidden="true"></i>';
  contactsButton.innerHTML = '<i class="fa-solid fa-address-book" aria-hidden="true"></i>';
  socialButton.title = "Círculos Sociais";
  contactsButton.title = "Contatos";
  socialButton.setAttribute("aria-label", socialButton.title);
  contactsButton.setAttribute("aria-label", contactsButton.title);
  for (const button of [socialButton, contactsButton]) button.type = "button";
  nav.append(socialButton, contactsButton);
  social.prepend(nav);
  const activate = tab => {
    SOCIAL_TABS.set(actor.uuid, tab);
    social.classList.toggle("gemini-contacts-active", tab === "contacts");
    socialButton.classList.toggle("active", tab !== "contacts");
    contactsButton.classList.toggle("active", tab === "contacts");
  };
  socialButton.addEventListener("click", event => { event.preventDefault(); activate("social"); });
  contactsButton.addEventListener("click", event => { event.preventDefault(); activate("contacts"); });
  const section = make("section", "gemini-contacts");
  const header = make("header", "gemini-contacts-header");
  header.append(make("h2", "gemini-contacts-title", "CONTATOS"));
  if (canEdit(actor)) {
    const add = make("button", "gemini-contacts-add", "+");
    add.type = "button";
    add.title = "Adicionar contato";
    add.addEventListener("click", event => {
      event.preventDefault();
      event.stopPropagation();
      void editEntry(actor).catch(reportError);
    });
    header.append(add);
  }
  const support = make("div", "gemini-contacts-support");
  support.append(make("h3", "gemini-contacts-support-title", "RETAGUARDA"),
    make("div", "gemini-contacts-grid gemini-contacts-support-grid"));
  section.append(header, make("div", "gemini-contacts-grid"), support);
  social.append(section);
  if (canEdit(actor)) {
    root.addEventListener("dragover", event => event.preventDefault(), { capture: true });
    root.addEventListener("drop", event => {
      let data;
      try { data = JSON.parse(event.dataTransfer.getData("text/plain")); }
      catch { return; }
      if (data?.type === "GeminiContact" || data?.type === "GeminiContactCatalog") {
        event.preventDefault();
        event.stopImmediatePropagation();
        void copyToActor(actor, data).catch(reportError);
      } else if (data?.type === "Item" && data.uuid && section.contains(event.target)) {
        event.preventDefault();
        event.stopImmediatePropagation();
        void fromUuid(data.uuid).then(item => grant(actor, item)).catch(reportError);
      }
    }, { capture: true });
  }
  activate(SOCIAL_TABS.get(actor.uuid) || "social");
  paint(section, actor);
}

async function grant(actor, item) {
  if (!item || item.documentName !== "Item") throw new Error("Arraste um Item válido para Contatos.");
  if (!canEdit(actor)) throw new Error("Somente mestres podem conceder contatos.");
  const entries = getEntries(actor);
  const sourceUuid = item.uuid || "";
  if (sourceUuid && entries.some(row => row.sourceUuid === sourceUuid)) {
    ui.notifications.warn(`${item.name} já está entre os contatos deste personagem.`);
    return;
  }
  const data = item.getFlag(MODULE_ID, "template") || {};
  const description = data.description ?? String(item.system?.description || "");
  entries.push(normalizeEntry({ ...data, id: foundry.utils.randomID(), sourceUuid,
    name: data.name || item.name, image: data.image || item.img, description,
    format: data.format || (data.description == null ? "html" : "markdown") }));
  await storeEntries(actor, entries);
  ui.notifications.info(`${item.name} foi adicionado aos contatos de ${actor.name}.`);
}

let catalogDocument = null;
let hub = null;

async function ensureCatalog() {
  if (!game.user.isGM) throw new Error("A Central de Contatos é exclusiva dos mestres.");
  if (catalogDocument && game.journal.get(catalogDocument.id)) return catalogDocument;
  catalogDocument = game.journal.find(doc => doc.getFlag(MODULE_ID, "isCatalog"));
  if (!catalogDocument) {
    catalogDocument = await foundry.documents.JournalEntry.create({
      name: "Gemini Force | Catálogo de Contatos",
      ownership: { default: 0 },
      flags: { [MODULE_ID]: { isCatalog: true, [CATALOG_FLAG]: [] } }
    });
  }
  return catalogDocument;
}

function getCatalogEntries(catalog) {
  const saved = catalog?.getFlag(MODULE_ID, CATALOG_FLAG);
  return Array.isArray(saved) ? saved.filter(row => row && typeof row === "object").map(normalizeEntry) : [];
}

async function storeCatalogEntries(catalog, entries) {
  if (!game.user.isGM || !catalog?.canUserModify(game.user, "update")) {
    throw new Error("Apenas mestres podem modificar o catálogo de contatos.");
  }
  await catalog.setFlag(MODULE_ID, CATALOG_FLAG, entries.map(normalizeEntry));
}

async function editCatalogEntry(catalog, previous = null) {
  const result = await promptEntry(previous);
  if (!result) return;
  const entries = getCatalogEntries(catalog);
  const index = previous ? entries.findIndex(entry => entry.id === previous.id) : -1;
  if (index >= 0) entries[index] = result;
  else entries.push(result);
  await storeCatalogEntries(catalog, entries);
}

async function deleteCatalogEntry(catalog, entry) {
  const confirmed = await foundry.applications.api.DialogV2.confirm({
    classes: ["gemini-contacts-dialog"],
    window: { title: "Excluir contato do catálogo" },
    content: `<p>Excluir <strong>${escapeHTML(entry.name)}</strong> do catálogo central?</p>`
  });
  if (confirmed) await storeCatalogEntries(catalog, getCatalogEntries(catalog).filter(row => row.id !== entry.id));
}

class ContactsHub extends foundry.applications.api.ApplicationV2 {
  static DEFAULT_OPTIONS = {
    id: "gemini-contacts-hub",
    classes: ["gemini-contacts-hub"],
    window: { title: "Central de Contatos", icon: "fa-solid fa-address-book", resizable: true },
    position: { width: 950, height: 690 }
  };

  constructor(catalog) {
    super();
    this.catalog = catalog;
    this.filter = "all";
    this.groupFilter = "";
    this.query = "";
  }

  async _renderHTML() {
    const entries = getCatalogEntries(this.catalog);
    const counts = Object.fromEntries(Object.keys(KINDS).map(kind => [kind, entries.filter(entry => entry.kind === kind).length]));
    const groups = [...new Set(entries.map(entry => entry.group).filter(Boolean))].sort((a, b) => a.localeCompare(b, "pt-BR"));
    const root = make("div", "gemini-hub-layout");
    root.innerHTML = `
      <aside class="gemini-hub-sidebar">
        <div class="gemini-hub-brand"><span class="gemini-hub-brand-mark">◆</span><span>GEMINI <small>FORCE</small></span></div>
        <div class="gemini-hub-sidebar-label">BIBLIOTECA</div>
        <nav class="gemini-hub-categories" aria-label="Categorias do catálogo">
          <button type="button" data-filter="all" class="${this.filter === "all" ? "active" : ""}"><i class="fa-solid fa-layer-group"></i><span>Todos</span><b>${entries.length}</b></button>
          ${Object.entries(KINDS).map(([kind, label]) => `<button type="button" data-filter="${kind}" class="${this.filter === kind ? "active" : ""}"><i class="fa-solid ${kind === "contact" ? "fa-address-book" : kind === "instructor" ? "fa-graduation-cap" : "fa-people-group"}"></i><span>${label === "Contato" ? "Contatos" : label === "Instrutor" ? "Instrutores" : label}</span><b>${counts[kind]}</b></button>`).join("")}
        </nav>
        ${groups.length ? `<div class="gemini-hub-sidebar-label gemini-hub-group-label">GRUPOS</div><nav class="gemini-hub-categories" aria-label="Grupos de contatos"><button type="button" data-group="" class="${!this.groupFilter ? "active" : ""}"><i class="fa-solid fa-border-all"></i><span>Todos os grupos</span></button>${groups.map(group => `<button type="button" data-group="${escapeHTML(group)}" class="${this.groupFilter === group ? "active" : ""}"><i class="fa-solid fa-folder"></i><span>${escapeHTML(group)}</span></button>`).join("")}</nav>` : ""}
        <div class="gemini-hub-sidebar-bottom"><img src="https://i.imgur.com/RNbTiyB.png" alt="Gemini Force" referrerpolicy="no-referrer"></div>
      </aside>
      <main class="gemini-hub-main">
        <header class="gemini-hub-header"><div><div class="gemini-hub-kicker">GEMINI FORCE / ADMINISTRAÇÃO</div><h2>Central de Contatos</h2><p>Crie uma vez, arraste para qualquer ficha.</p></div><button type="button" data-create class="gemini-hub-create"><i class="fa-solid fa-plus"></i> Novo contato</button></header>
        <div class="gemini-hub-summary">
          <div><small>NO CATÁLOGO</small><strong>${entries.length}</strong><span>NPCs prontos para conceder</span></div>
          <div><small>CONTATOS</small><strong>${counts.contact}</strong><span>Laços e informações</span></div>
          <div><small>INSTRUTORES</small><strong>${counts.instructor}</strong><span>Especialidades e ensino</span></div>
          <div><small>RETAGUARDA</small><strong>${counts.support}</strong><span>Apoio à equipe</span></div>
        </div>
        <section class="gemini-hub-library"><div class="gemini-hub-library-head"><div><h3>${this.filter === "all" ? "Todos os contatos" : KINDS[this.filter]}</h3><p>Arraste um card para a ficha de um personagem. Você também pode soltar aqui um contato já criado em ficha.</p></div><label class="gemini-hub-search"><i class="fa-solid fa-magnifying-glass"></i><input type="search" placeholder="Buscar por nome ou grupo" value="${escapeHTML(this.query)}" aria-label="Buscar contatos"></label></div><div class="gemini-hub-grid"></div><div class="gemini-hub-empty" hidden>Nenhum contato encontrado. Crie um ou arraste um card de uma ficha até aqui.</div></section>
      </main>
    `;
    const grid = root.querySelector(".gemini-hub-grid");
    for (const entry of entries.filter(entry => (this.filter === "all" || entry.kind === this.filter)
      && (!this.groupFilter || entry.group === this.groupFilter))) {
      const wrapper = make("div", "gemini-hub-card-wrap");
      const card = make("button", "gemini-hub-card");
      card.type = "button";
      card.draggable = true;
      card.dataset.search = `${entry.name} ${entry.group}`.toLocaleLowerCase("pt-BR");
      const image = make("img", "gemini-hub-card-image");
      image.src = safeImage(entry.image);
      image.alt = "";
      const info = make("div", "gemini-hub-card-info");
      info.append(make("strong", "gemini-hub-card-name", entry.name),
        make("span", "gemini-hub-card-kind", KINDS[entry.kind]),
        make("span", "gemini-hub-card-detail", entry.group || caption(entry)));
      card.append(image, info);
      card.addEventListener("click", () => void editCatalogEntry(this.catalog, entry).catch(reportError));
      card.addEventListener("dragstart", event => {
        event.dataTransfer.setData("text/plain", JSON.stringify({
          type: "GeminiContactCatalog", catalogUuid: this.catalog.uuid, id: entry.id
        }));
        event.dataTransfer.effectAllowed = "copy";
      });
      const remove = make("button", "gemini-hub-card-delete", "×");
      remove.type = "button";
      remove.title = `Excluir ${entry.name} do catálogo`;
      remove.setAttribute("aria-label", remove.title);
      remove.addEventListener("click", () => void deleteCatalogEntry(this.catalog, entry).catch(reportError));
      wrapper.append(card, remove);
      grid.append(wrapper);
    }
    return root;
  }

  _replaceHTML(result, content) {
    content.replaceChildren(result);
  }

  _onRender(context, options) {
    super._onRender(context, options);
    const root = this.element.querySelector(".gemini-hub-layout");
    if (!root) return;
    const applySearch = () => {
      let visible = 0;
      for (const wrapper of root.querySelectorAll(".gemini-hub-card-wrap")) {
        const match = wrapper.querySelector(".gemini-hub-card").dataset.search.includes(this.query.toLocaleLowerCase("pt-BR"));
        wrapper.hidden = !match;
        if (match) visible++;
      }
      root.querySelector(".gemini-hub-empty").hidden = visible > 0;
    };
    root.querySelector(".gemini-hub-search input").addEventListener("input", event => {
      this.query = event.target.value;
      applySearch();
    });
    root.querySelector("[data-create]").addEventListener("click", () => void editCatalogEntry(this.catalog).catch(reportError));
    for (const button of root.querySelectorAll("[data-filter]")) {
      button.addEventListener("click", () => {
        this.filter = button.dataset.filter;
        void this.render();
      });
    }
    for (const button of root.querySelectorAll("[data-group]")) {
      button.addEventListener("click", () => {
        this.groupFilter = button.dataset.group;
        void this.render();
      });
    }
    root.addEventListener("dragover", event => event.preventDefault());
    root.addEventListener("drop", event => {
      let data;
      try { data = JSON.parse(event.dataTransfer.getData("text/plain")); }
      catch { return; }
      if (data?.type !== "GeminiContact") return;
      event.preventDefault();
      void entryFromDrag(data).then(async entry => {
        if (!entry) throw new Error("O contato arrastado não foi encontrado.");
        await storeCatalogEntries(this.catalog, [...getCatalogEntries(this.catalog), cloneEntry(entry)]);
        ui.notifications.info(`${entry.name} foi copiado para o catálogo.`);
      }).catch(reportError);
    });
    applySearch();
  }
}

async function openHub() {
  if (!game.user.isGM) return;
  const catalog = await ensureCatalog();
  if (hub?.rendered) return hub.bringToFront();
  hub = new ContactsHub(catalog);
  await hub.render({ force: true });
}

Hooks.on("getSceneControlButtons", controls => {
  if (!game.user.isGM) return;
  controls.geminiContacts = {
    name: "geminiContacts",
    title: "Central de Contatos",
    icon: "fa-solid fa-address-book",
    order: 75,
    visible: true,
    onChange: (_event, active) => { if (active) void openHub().catch(reportError); },
    tools: {
      openHub: {
        name: "openHub", title: "Abrir Central de Contatos",
        icon: "fa-solid fa-address-book", order: 0, button: true, visible: true,
        onChange: () => void openHub().catch(reportError)
      }
    }
  };
});

Hooks.on("updateJournalEntry", journal => {
  if (journal.id === catalogDocument?.id && hub?.rendered) void hub.render().catch(reportError);
});

Hooks.once("ready", () => {
  game.modules.get(MODULE_ID).api = Object.freeze({
    grant,
    list: actor => getEntries(actor),
    openHub,
    remove: async (actor, id) => {
      const entry = getEntries(actor).find(row => row.id === id);
      if (entry) await deleteEntry(actor, entry);
    }
  });
});

Hooks.on("renderActorSheet", (sheet, html) => {
  const root = html instanceof HTMLElement ? html : html?.[0];
  if (root && sheet.actor) install(sheet.actor, root);
});
