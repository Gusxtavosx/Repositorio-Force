# Gemini Force · Escudo do Mestre

Módulo de consulta para Foundry VTT 14. Mestres acessam o escudo completo; jogadores acessam apenas os Efeitos Especiais. A interface adapta o arquivo `escudo_do_mestre.html` fornecido pelo projeto Gemini Force.

## Instalação local para teste

Extraia a pasta `gemini-master-screen` do ZIP em `Data/modules/`, ative o módulo no mundo e recarregue o Foundry. No menu de ferramentas da cena, os Mestres veem **Escudo do Mestre**; os jogadores veem **Efeitos Especiais**. A API `game.modules.get("gemini-master-screen").api.open()` abre a vista correspondente às permissões da conta logada.

## Consulta na mesa

- Sete áreas: visão geral, combate e dano, efeitos especiais, tenacidade, sequelas, fadiga e veículos, calculadoras.
- Na primeira abertura de cada Mestre neste mundo e navegador, uma tela de boas-vindas mostra o nome da conta logada sobre o escudo desfocado. Ao entrar, ela não aparece de novo nesse navegador.
- Busca global por nome ou texto das regras; `Ctrl+K`/`⌘K` abre a busca. Setas e Enter levam ao resultado.
- 24 efeitos especiais com descrições completas nos cards, incluindo mecânica, testes e quem resiste quando houver. Eles podem ser buscados, filtrados e fixados para acesso rápido. Os favoritos ficam no navegador de cada usuário.
- Os jogadores carregam uma interface exclusiva de Efeitos Especiais; as outras seis áreas e suas regras são carregadas somente para Mestres.
- Rolagens de tabelas d20 e d100 resolvidas localmente no cliente do Mestre e exibidas em uma janela de detalhes. Não geram mensagens no chat.
- Cálculos de empurrão e queda seguem os valores do HTML original. O modificador de dano usa a progressão de Destined além de 80 e permite somar FOR + TAM, FOR + TAM + metade da CON (arredondada para cima) ou FOR + TAM + CON inteira, sem limite de tabela.

O módulo não solicita rede externa, não grava dados no mundo e não altera fichas. A base das outras regras foi transcrita do HTML recebido; os efeitos são uma adaptação para o Gemini Force a partir do material de Destined enviado pelo projeto. Confira as regras da sua campanha antes de usá-lo como referência oficial.

Na atualização da versão 0.1 para a 0.2, fixe novamente seus efeitos favoritos: o catálogo foi reorganizado para incorporar os nomes e manobras do Gemini Force.

Para o manifesto remoto e atualização automática, publique os arquivos do módulo e acrescente `manifest`, `download` e `url` em `module.json`. Esta versão é um pacote local para validação.
