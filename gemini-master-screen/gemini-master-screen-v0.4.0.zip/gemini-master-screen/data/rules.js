// Text and tables adapted from escudo_do_mestre.html supplied by the project.
export const rules = {
  "overview": {
    "time": [
      [
        "Rodada de Combate",
        "5 seg"
      ],
      [
        "Tempo Narrativo",
        "Mestre"
      ],
      [
        "Recuperação PP (Base)",
        "2/h"
      ],
      [
        "Recuperação PP (Descanso)",
        "Dobro"
      ]
    ],
    "luck": [
      "Rolar novamente qualquer teste.",
      "Mitigar Dano: De Incapacitado para Sério.",
      "Ação extra (Reação) com PA zerados.",
      "Recuperar 1d4+1 PP imediatamente."
    ],
    "difficulty": [
      [
        "Muito Fácil",
        "Perícia x2"
      ],
      [
        "Fácil",
        "Perícia +50%"
      ],
      [
        "Padrão",
        "Normal"
      ],
      [
        "Difícil",
        "Perícia x0.66"
      ],
      [
        "Formidável",
        "Perícia x0.5"
      ],
      [
        "Hercúleo",
        "Perícia x0.2"
      ]
    ],
    "success": {
      "headers": [
        "Rolagem",
        "Resultado",
        "Efeito Prático"
      ],
      "rows": [
        {
          "range": "",
          "cells": [
            "≤ 10% da Perícia",
            "Sucesso Crítico",
            "Garante 1 Efeito Especial Extra + Efeitos Críticos."
          ],
          "colspans": [
            1,
            1,
            1
          ]
        },
        {
          "range": "",
          "cells": [
            "≤ Perícia",
            "Sucesso Padrão",
            "Ação concluída. Ganha Efeito Especial se oponente falhar."
          ],
          "colspans": [
            1,
            1,
            1
          ]
        },
        {
          "range": "",
          "cells": [
            "> Perícia",
            "Falha",
            "Ação não concluída. Concede Efeito ao oponente (em opostos)."
          ],
          "colspans": [
            1,
            1,
            1
          ]
        },
        {
          "range": "",
          "cells": [
            "99 ou 00",
            "Fumble",
            "Desastre. Oponente ganha acesso a Efeitos Críticos."
          ],
          "colspans": [
            1,
            1,
            1
          ]
        }
      ]
    }
  },
  "injuries": [
    {
      "name": "Ferimento Leve",
      "details": [
        "PV do local acima de zero. Nenhuma penalidade mecânica."
      ]
    },
    {
      "name": "Ferimento Sério",
      "details": [
        "PV do local cai para Zero ou Negativo (não atingindo o máximo).",
        "Requer Teste Oposto de Tolerância contra o ataque.",
        "Sucesso: Testes com o local ficam 1 grau mais difíceis.",
        "Falha: Local inutilizável. (Se Cabeça/Peito/Abdômen, cai Incapacitado)."
      ]
    },
    {
      "name": "Ferimento Persistente / Incapacitado",
      "details": [
        "PV do local cai para negativo igual ou maior que PV original.",
        "Incapacitado imediatamente. Teste de Tolerância contra ataque.",
        "Sucesso: Inconsciente; recupera para Ferimento Sério com medicina.",
        "Falha: Sofre Ferimento Persistente no local.",
        "Falha Crítica (Fumble): Morrendo (minutos = Taxa de Cura x2)."
      ]
    }
  ],
  "headWarning": "Regra: Dano Grave na Cabeça Qualquer dano que leve a Cabeça à condição de Ferimento Grave sem mitigação causa morte imediata, sem teste para sobreviver. Gastar Sorte reduz para Sério.",
  "effects": [
    {
      "name": "Atordoar um Local",
      "offense": true,
      "defense": false,
      "critical": false,
      "description": "Após um golpe Desarmado ou Concussivo que cause dano depois da armadura, o local atingido fica inutilizado por tantos turnos quanto os pontos de dano sofridos. Peito ou abdômen deixam o alvo capaz apenas de se defender; um golpe na cabeça impede qualquer ação enquanto durar o efeito.",
      "tests": "O alvo faz Tolerância (Endurance) oposta à rolagem original de ataque. Se vencer, evita o atordoamento."
    },
    {
      "name": "Agarrar o Inimigo",
      "offense": true,
      "defense": false,
      "critical": false,
      "description": "Com uma mão livre ou apêndice equivalente, segure um alvo ao alcance de combate Desarmado. Ele não consegue se afastar enquanto permanecer agarrado.",
      "tests": "No próprio turno, o alvo pode gastar 1 Ponto de Ação e tentar uma disputa de Força Bruta (Brawn) ou Desarmado contra quem o segura; quem agarra determina qual das duas perícias será usada."
    },
    {
      "name": "Precisão de um Atirador",
      "offense": true,
      "defense": false,
      "critical": false,
      "description": "Em um ataque à distância, desloque o local sorteado do acerto em um passo para uma região adjacente. O efeito pode ser escolhido novamente para mover mais um passo por escolha. Não muda o resultado do ataque para qualquer local desejado. Não exige teste adicional."
    },
    {
      "name": "Ficar de Pé",
      "offense": false,
      "defense": true,
      "critical": false,
      "description": "Se estiver caído, aproveite a abertura criada pela defesa para se levantar imediatamente, inclusive enquanto estiver engajado em combate corpo a corpo. Não exige ação de movimento nem novo teste."
    },
    {
      "name": "Empurrar o Adversário",
      "offense": true,
      "defense": false,
      "critical": false,
      "description": "Empurre o alvo 1 m para cada 2 pontos do dano rolado com escudo ou Força Aprimorada; com outros ataques Desarmados ou Concussivos, 1 m para cada 3 pontos. Use o dano antes de armadura ou bloqueio. Só funciona contra alvos de até o dobro do TAM de quem ataca.",
      "tests": "Se colidir com um obstáculo, o alvo faz Atletismo ou Acrobacia em dificuldade Difícil para não cair."
    },
    {
      "name": "Escolher o Local",
      "offense": true,
      "defense": false,
      "critical": false,
      "description": "Escolha diretamente o local do corpo atingido pelo golpe, desde que esteja ao alcance. Em ataques à distância, só pode ser aplicado com acerto Crítico, conforme a regra do Gemini Force. Não exige novo teste."
    },
    {
      "name": "Danificar um Item",
      "offense": true,
      "defense": true,
      "critical": false,
      "description": "Em um ataque ou defesa, direcione o dano da arma a um objeto carregado ou empunhado pelo adversário em vez de ferir o próprio alvo. Subtraia os Pontos de Armadura do item e reduza seus Pontos de Vida; ao chegar a zero, ele é destruído. Armadura vestida requer arma com a propriedade adequada para danificá-la. Não há teste adicional."
    },
    {
      "name": "Causar uma Distração",
      "offense": true,
      "defense": true,
      "critical": false,
      "description": "Intimide, provoque ou engane o oponente durante o ataque ou defesa. Se ele cair na distração, o próximo teste que fizer como parte de uma ação ou reação fica um grau de dificuldade mais difícil.",
      "tests": "Quem distrai rola Enganação, Influência ou Intimidação como ação livre; o alvo opõe Intuição (Insight). Com um Poder, use o teste indicado pelo Poder; na ausência dele, Atletismo para manifestações físicas ou Vontade para mentais."
    },
    {
      "name": "Derrubar o Oponente",
      "offense": true,
      "defense": true,
      "critical": false,
      "description": "Derrube o adversário para deixá-lo caído. Pode ser escolhido em ataque ou defesa, respeitando a distância e a possibilidade física de alcançar o alvo.",
      "tests": "O alvo escolhe Força Bruta (Brawn), Evasão ou Acrobacia e faz teste oposto à rolagem original de quem aplicou o efeito. Se perder, cai. Alvos com mais de duas pernas podem usar Atletismo com um grau de facilidade."
    },
    {
      "name": "Desarmar Oponente",
      "offense": true,
      "defense": true,
      "critical": false,
      "description": "Arranque ou golpeie o item empunhado pelo alvo. Se o desarme funcionar, ele cai aos pés do alvo quando o Modificador de Dano de quem desarma não for positivo, ou é lançado a uma distância em metros equivalente ao resultado desse modificador. Com uma mão livre e ataque ou defesa Desarmado, é possível tomar a arma em vez de lançá-la. Exige alvo com até o dobro do TAM de quem desarma.",
      "tests": "O alvo faz Estilo de Combate oposto à rolagem original de ataque ou defesa. A resistência fica um grau mais difícil se a arma desarmante for maior, ou um grau mais fácil se for menor."
    },
    {
      "name": "Retomar Cobertura",
      "offense": true,
      "defense": true,
      "critical": false,
      "description": "Volte imediatamente para trás de uma cobertura que já estava usando e que ainda esteja adjacente. Não consome ação de movimento nem exige teste adicional."
    },
    {
      "name": "Emaranhar um Local",
      "offense": true,
      "defense": true,
      "critical": false,
      "description": "Com arma de emaranhamento ou Poder capaz de prender, imobilize o local atingido. Braço preso não usa o que segura; perna presa impede movimento; cabeça, peito ou abdômen presos tornam os testes um grau mais difíceis. No turno seguinte, quem mantém a imobilização pode gastar 1 Ponto de Ação para tentar Derrubar automaticamente.",
      "tests": "Para escapar, o alvo gasta 1 Ponto de Ação e disputa Força Bruta (Brawn) com quem o prendeu; também pode danificar ou desarmar o objeto que o prende."
    },
    {
      "name": "Golpes Múltiplos",
      "offense": true,
      "defense": false,
      "critical": false,
      "description": "Gaste 1 Ponto de Ação para fazer imediatamente outro ataque Desarmado com uma parte do corpo diferente da usada no golpe anterior. O ataque extra ocorre no mesmo turno e pode vir após um golpe inicial com arma.",
      "tests": "Quem executa rola normalmente o ataque Desarmado adicional; o defensor pode reagir conforme as regras usuais de combate."
    },
    {
      "name": "Golpe de Impacto",
      "offense": true,
      "defense": false,
      "critical": false,
      "description": "Role duas vezes o dano básico da arma, ataque Desarmado ou Poder e fique com o maior resultado. O Modificador de Dano não é rolado duas vezes; aplique-o normalmente após escolher o melhor dano básico."
    },
    {
      "name": "Causar Restrição",
      "offense": true,
      "defense": false,
      "critical": false,
      "description": "Com arma de fogo automática em ataque à distância, force o inimigo a se abrigar ou permanecer coberto. Mesmo que o disparo não cause dano, se o efeito vencer o alvo não poderá atacar no próximo turno; ele ainda pode se mover protegido, recarregar ou praticar outras ações.",
      "tests": "O alvo faz Vontade oposta à rolagem original do ataque à distância. Se vencer, evita a Restrição."
    },
    {
      "name": "Pressionar Vantagem",
      "offense": true,
      "defense": true,
      "critical": false,
      "description": "Mantenha o adversário na defensiva ou provoque uma abertura: ele não pode realizar uma Ação de Ataque no próximo turno. Continua livre para defender, movimentar-se ou executar outras ações permitidas. Não há teste adicional."
    },
    {
      "name": "Recarga Rápida",
      "offense": true,
      "defense": false,
      "critical": false,
      "description": "Em arma com tempo de recarga, reduza em um turno a preparação do próximo disparo para cada vez que escolher este efeito. Pode ser aplicado várias vezes na mesma troca. Se chegar a zero, recarregar passa a ser uma ação livre. Não há teste adicional."
    },
    {
      "name": "Stand Fast",
      "offense": false,
      "defense": true,
      "critical": false,
      "description": "Firme sua posição ao defender para ignorar o recuo ou a Pancada (Bash) causada pelo ataque recebido. Aplica-se ao deslocamento forçado; não remove por si só o dano do golpe. Não exige teste adicional."
    },
    {
      "name": "Bater em Retirada",
      "offense": true,
      "defense": true,
      "critical": false,
      "description": "Aproveite a abertura no combate para fazer um deslocamento rápido para longe do oponente, sem precisar rolar para desengajar. Este efeito não amplia o alcance normal do deslocamento."
    },
    {
      "name": "Contornar a Defesa",
      "offense": true,
      "defense": false,
      "critical": true,
      "description": "Em ataque Crítico, escolha uma proteção para superar: ignore a armadura do local atingido, ignore a cobertura alcançável ou trate uma Esquiva/Bloqueio bem-sucedido como falho. Se a cobertura não puder ser atravessada de modo plausível, um disparo de precisão pode contorná-la, mas o dano é rolado duas vezes e fica o menor."
    },
    {
      "name": "Aprimorar Defesa",
      "offense": false,
      "defense": true,
      "critical": true,
      "description": "Após uma defesa Crítica, escolha: bloquear integralmente o ataque apesar do tamanho/Força da arma inimiga; preparar um contra-ataque que anula, pelo restante do combate, um Efeito Especial específico usado por esse adversário e devolve um efeito comum; ou libertar-se automaticamente de agarramento/emaranhamento sem gastar Ponto de Ação."
    },
    {
      "name": "Forçar Falha do Oponente",
      "offense": true,
      "defense": true,
      "critical": true,
      "description": "Quando o oponente sofre um Fumble, combine este efeito com outro Efeito Especial que normalmente permite resistência por teste oposto. A resistência do oponente contra o efeito combinado falha automaticamente, seja a vantagem obtida em ataque ou defesa."
    },
    {
      "name": "Maximizar Dano",
      "offense": true,
      "defense": false,
      "critical": true,
      "description": "Em um ataque Crítico, um dado do dano básico da arma ou do Poder assume automaticamente o seu valor máximo; role os demais dados normalmente. Pode repetir o efeito para maximizar outros dados do mesmo ataque, mas não os dados do Modificador de Dano."
    },
    {
      "name": "Selecionar Alvo",
      "offense": false,
      "defense": true,
      "critical": true,
      "description": "Quando o atacante sofre um Fumble, desvie o ataque para outro alvo: em combate corpo a corpo, ele deve estar adjacente e ao alcance da arma; à distância, deve estar na linha de tiro original. O novo alvo é atingido automaticamente, sofre dano normal e o golpe não gera Efeitos Especiais. Se plausível, o próprio atacante pode ser atingido em um local aleatório."
    }
  ],
  "intensity": [
    [
      "0. Leve",
      "Teste Padrão (Perde 1 pt)"
    ],
    [
      "1. Inquietante",
      "Teste Difícil (Perde 1d3)"
    ],
    [
      "2. Perturbador",
      "Formidável (Perde 1d6)"
    ],
    [
      "3. Chocante",
      "Hercúleo (Perde 1d10)"
    ],
    [
      "4. Devastador",
      "Sem Esperança (Perde 1d20)"
    ]
  ],
  "intensityNotes": [
    "* Se a perda for ≥ 50% da Tenacidade atual: Condição Imediata . * Se a Tenacidade ficar negativa : Condição torna-se Permanente."
  ],
  "loss": [
    {
      "name": "Perda de até 20% em uma única situação",
      "description": "Choque Leve: -5% em testes de Percepção, Persuasão e Batalha por 1d3 rodadas."
    },
    {
      "name": "Perda de 21-40% em uma única situação",
      "description": "Colapso Temporário (Rola 1d6): 1-2: Paralisia (1d6 turnos). 3-4: Fuga Irracional (1d3 rodadas). 5-6: Comportamento Irracional (1d6 minutos, +1 Nível Dificuldade)."
    },
    {
      "name": "Tenacidade total cai abaixo de 50% do original",
      "description": "Transtorno Temporário: -10% em testes sociais. Para cada episódio de fobia/estresse, teste Vontade ou sofre Nausea por 1d3 turnos."
    },
    {
      "name": "Tenacidade total cai abaixo de 20% do original",
      "description": "Desordem Mental Permanente: Esquizofrenia, TOC ou Síndrome do Pânico."
    },
    {
      "name": "Tenacidade chega a 0",
      "description": "Colapso Total: O personagem enlouquece permanentemente e torna-se um NPC."
    }
  ],
  "immediate": {
    "headers": [
      "1d20",
      "Medo",
      "Horror",
      "Loucura / Psiônico"
    ],
    "rows": [
      {
        "range": "1-2",
        "cells": [
          "1-2",
          "Desmoralizado (1d8 rod)",
          "Balbucia (2d12 rod)",
          "Balbucia (2d6 rod)"
        ],
        "colspans": [
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "3-6",
        "cells": [
          "3-6",
          "Desmoralizado (2d6 rod)",
          "Repulsa (1d6 rod)",
          "Balbucia (2d12 rod)"
        ],
        "colspans": [
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "7-9",
        "cells": [
          "7-9",
          "Desmaia (1d6 rod)",
          "Enfurecido (2d6 rod)",
          "Enfurecido (2d6 rod)"
        ],
        "colspans": [
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "10-12",
        "cells": [
          "10-12",
          "Foge em terror (1d8 rod)",
          "Desmaia (1d6 rod)",
          "Desmaia (1d6 rod)"
        ],
        "colspans": [
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "13-15",
        "cells": [
          "13-15",
          "Foge em terror (2d6 rod)",
          "Foge em terror (2d6 rod)",
          "Desmaia (1d8 rod)"
        ],
        "colspans": [
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "16-17",
        "cells": [
          "16-17",
          "Paralisado (1d2 rod)",
          "Paralisado (1d4 rod)",
          "Foge em terror (2d6 rod)"
        ],
        "colspans": [
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "18-20",
        "cells": [
          "18-20",
          "Paralisado (1d4 rod)",
          "Nauseado (1d6 rod)",
          "Paralisado (1d4 rod)"
        ],
        "colspans": [
          1,
          1,
          1,
          1
        ]
      }
    ]
  },
  "delayed": {
    "headers": [
      "1d20",
      "Medo",
      "Horror",
      "Loucura / Psiônico"
    ],
    "rows": [
      {
        "range": "1-3",
        "cells": [
          "1-3",
          "Perturbado (1d4 sem)",
          "Amnésia (1d12 meses)",
          "Amnésia (1d12 meses)"
        ],
        "colspans": [
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "4-6",
        "cells": [
          "4-6",
          "Perturbado (1d6 meses)",
          "Perturbado (1d6 meses)",
          "Catatonia (1d12 sem)"
        ],
        "colspans": [
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "7-8",
        "cells": [
          "7-8",
          "Pesadelos (1d6 sem)",
          "Perturbado (1d12 meses)",
          "Delirante (1d6 meses)"
        ],
        "colspans": [
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "9-10",
        "cells": [
          "9-10",
          "Pesadelos (1d4 meses)",
          "Pesadelos (1d4 meses)",
          "Fuga Dissociativa (1d12 m)"
        ],
        "colspans": [
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "11-12",
        "cells": [
          "11-12",
          "Pesadelos (1d12 meses)",
          "Pesadelos (1d12 meses)",
          "Alucinações (1d6 sem)"
        ],
        "colspans": [
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "13-14",
        "cells": [
          "13-14",
          "Paranoia (1d6 sem)",
          "Obsessivo (1d12 meses)",
          "Melancolia (1d6 meses)"
        ],
        "colspans": [
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "15-16",
        "cells": [
          "15-16",
          "Paranoia (1d4 meses)",
          "Obsessivo (1d4 anos)",
          "Obsessivo (1d12 meses)"
        ],
        "colspans": [
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "17-18",
        "cells": [
          "17-18",
          "Fobia (1d12 meses)",
          "Fobia (2d12 meses)",
          "Paranoia (1d12 meses)"
        ],
        "colspans": [
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "19-20",
        "cells": [
          "19-20",
          "Fobia (1d4 anos)",
          "Fobia (1d4 anos)",
          "Fobia (1d4 anos)"
        ],
        "colspans": [
          1,
          1,
          1,
          1
        ]
      }
    ]
  },
  "sequelae": {
    "headers": [
      "1d100",
      "Efeito",
      "Descrição"
    ],
    "rows": [
      {
        "range": "01-05",
        "cells": [
          "01-05",
          "Debilitação Vital",
          "-1 Ponto de Ação permanente. (Apenas Peito/Abdômen. Se rolado Cabeça, role novamente)."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      },
      {
        "range": "06-10",
        "cells": [
          "06-10",
          "Dor Crônica Leve",
          "+1 Nível de Dificuldade em testes de tolerância para a localização."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      },
      {
        "range": "11-15",
        "cells": [
          "11-15",
          "Fraqueza Muscular",
          "-2 pontos permanentes na FOR da localização afetada."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      },
      {
        "range": "16-20",
        "cells": [
          "16-20",
          "Tremores Leves",
          "-5% em perícias de destreza fina (Ofício, Primeiros Socorros, etc)."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      },
      {
        "range": "21-25",
        "cells": [
          "21-25",
          "Sensibilidade ao Toque",
          "Dor de Agonia se for tocado bruscamente. Dura 1d3 turnos."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      },
      {
        "range": "26-30",
        "cells": [
          "26-30",
          "Respiração Restrita",
          "-5% em Atletismo/Furtividade. (Apenas Peito/Abdômen. Se rolado Cabeça, role novamente)."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      },
      {
        "range": "31-35",
        "cells": [
          "31-35",
          "Visão/Audição Afetada",
          "-10% em Percepção visual/auditiva. (Apenas Cabeça. Caso contrário role novamente)."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      },
      {
        "range": "36-40",
        "cells": [
          "36-40",
          "Nervos Atrapalhados",
          "5% de chance de Fumble em ações com a localização atingida."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      },
      {
        "range": "41-45",
        "cells": [
          "41-45",
          "Pesadelos Frequentes",
          "+1 Nível de Dificuldade em descanso e recuperação."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      },
      {
        "range": "46-50",
        "cells": [
          "46-50",
          "Metabolismo Lento",
          "+1 Dificuldade para resistir venenos/doenças por ingestão."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      },
      {
        "range": "51-55",
        "cells": [
          "51-55",
          "Convulsões Leves",
          "Sob estresse intenso/dor, teste Vontade (Difícil) ou Paralisia por 1d3 turnos."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      },
      {
        "range": "56-60",
        "cells": [
          "56-60",
          "Afasia",
          "Incapaz de falar. Comunicação escrita/sinais com +1 Dificuldade. (Apenas Cabeça)."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      },
      {
        "range": "61-65",
        "cells": [
          "61-65",
          "Órgão Fragilizado",
          "-2 HP permanente na localização."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      },
      {
        "range": "66-70",
        "cells": [
          "66-70",
          "Vulnerabilidade Térmica",
          "+1 Dificuldade para resistir a frio e sangramento."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      },
      {
        "range": "71-75",
        "cells": [
          "71-75",
          "Trauma de Confinamento",
          "Ganha Paixão: Claustrofobia. Em locais fechados, +1 Dificuldade em perícias."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      },
      {
        "range": "76-80",
        "cells": [
          "76-80",
          "Vertigem Ocasional",
          "Sofre de Náusea no início do combate por 1d3 turnos. (Apenas Cabeça)."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      },
      {
        "range": "81-85",
        "cells": [
          "81-85",
          "Recuperação Lenta",
          "A Taxa de Cura Permanente é reduzida em 1."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      },
      {
        "range": "86-90",
        "cells": [
          "86-90",
          "Imunidade Frágil",
          "+1 Dificuldade para resistir a todas as doenças e venenos."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      },
      {
        "range": "91-95",
        "cells": [
          "91-95",
          "Colapso Súbito",
          "Ao sofrer Ferimento Grave, teste Resistência (Difícil) ou desmaia por 1d2 Rodadas."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      },
      {
        "range": "96-00",
        "cells": [
          "96-00",
          "Efeito Múltiplo",
          "Role duas vezes nesta tabela, ignorando novos Efeitos Múltiplos."
        ],
        "colspans": [
          1,
          1,
          1
        ]
      }
    ]
  },
  "fatigue": {
    "headers": [
      "Estado",
      "Dificuldade Básica",
      "Movimento",
      "Iniciativa",
      "Pontos Ação",
      "Recuperação"
    ],
    "rows": [
      {
        "range": "",
        "cells": [
          "Ileso (Fresh)",
          "Normal",
          "Normal",
          "Normal",
          "Normal",
          "-"
        ],
        "colspans": [
          1,
          1,
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "",
        "cells": [
          "Ofegante (Winded)",
          "Difícil",
          "Normal",
          "Normal",
          "Normal",
          "15 min"
        ],
        "colspans": [
          1,
          1,
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "",
        "cells": [
          "Cansado (Tired)",
          "Difícil",
          "-1 m",
          "Normal",
          "Normal",
          "3 horas"
        ],
        "colspans": [
          1,
          1,
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "",
        "cells": [
          "Fatigado (Wearied)",
          "Formidável",
          "-2 m",
          "Normal",
          "Normal",
          "6 horas"
        ],
        "colspans": [
          1,
          1,
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "",
        "cells": [
          "Exausto (Exhausted)",
          "Formidável",
          "Metade",
          "-4",
          "-1",
          "12 horas"
        ],
        "colspans": [
          1,
          1,
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "",
        "cells": [
          "Debilitado (Debilitated)",
          "Hercúleo",
          "Metade",
          "-6",
          "-2",
          "18 horas"
        ],
        "colspans": [
          1,
          1,
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "",
        "cells": [
          "Incapacitado",
          "Hercúleo",
          "Imóvel",
          "-8",
          "-3",
          "24 horas"
        ],
        "colspans": [
          1,
          1,
          1,
          1,
          1,
          1
        ]
      },
      {
        "range": "",
        "cells": [
          "Semi-Consciente",
          "Sem Ação Possível",
          "36 horas"
        ],
        "colspans": [
          1,
          4,
          1
        ]
      },
      {
        "range": "",
        "cells": [
          "Morto / Morrendo",
          "Inconsciente, morrerá em minutos = Taxa Cura x2"
        ],
        "colspans": [
          1,
          5
        ]
      }
    ]
  },
  "accidents": {
    "headers": [
      "1d100",
      "Resultado / Efeito"
    ],
    "rows": [
      {
        "range": "01-25",
        "cells": [
          "01-25",
          "Desvio: Perda temporária de controle. Reduz vel. em 1 passo por 5 seg."
        ],
        "colspans": [
          1,
          1
        ]
      },
      {
        "range": "26-40",
        "cells": [
          "26-40",
          "Derrapagem/Giro: Luta para manter controle. Vel. cai 2 passos por 10 seg."
        ],
        "colspans": [
          1,
          1
        ]
      },
      {
        "range": "41-50",
        "cells": [
          "41-50",
          "Parada Grave: Veículo fica voltado à direção errada e para por 15 seg."
        ],
        "colspans": [
          1,
          1
        ]
      },
      {
        "range": "51-60",
        "cells": [
          "51-60",
          "Capotamento Leve: 3d10 de dano na Estrutura. Ocupantes Teste de Tolerância ou 1d10 em 1d3 Locais."
        ],
        "colspans": [
          1,
          1
        ]
      },
      {
        "range": "61-70",
        "cells": [
          "61-70",
          "Capotamento Grave: 3d10+10 dano na Estrutura. Ocupantes 1d10 em 1d3 Locais (ou 2d10 se falhar Tol.)."
        ],
        "colspans": [
          1,
          1
        ]
      },
      {
        "range": "71-80",
        "cells": [
          "71-80",
          "Perda Total: Dano reduz Estrutura a 0. Ocupantes sofrem como Capotamento Grave."
        ],
        "colspans": [
          1,
          1
        ]
      },
      {
        "range": "81-90",
        "cells": [
          "81-90",
          "Explosão (Atrasada): Perda Total + combustível inflama em 1d20+10 seg. 1d6 dano fogo em 1d6 locais."
        ],
        "colspans": [
          1,
          1
        ]
      },
      {
        "range": "91-98",
        "cells": [
          "91-98",
          "Explosão Imediata: Como acima, porém a explosão é imediata."
        ],
        "colspans": [
          1,
          1
        ]
      },
      {
        "range": "99-00",
        "cells": [
          "99-00",
          "Acidente Catastrófico: Estrutura a 0. Ocupantes Tolerância ou PV vão para negativo máx em 1d6 locais."
        ],
        "colspans": [
          1,
          1
        ]
      }
    ]
  }
};
