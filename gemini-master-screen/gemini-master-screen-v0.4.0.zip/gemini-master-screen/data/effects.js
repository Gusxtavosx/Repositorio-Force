// Only the Efeitos Especiais catalog is loaded by players.
export const effects = [
  {
    "name": "Atordoar um Local",
    "offense": true,
    "defense": false,
    "critical": false,
    "description": "Após um golpe Desarmado ou Concussivo que cause dano depois da armadura, o local atingido fica inutilizado por tantos turnos quanto os pontos de dano sofridos. Peito ou abdômen deixam o alvo capaz apenas de se defender; um golpe na cabeça impede qualquer ação enquanto durar o efeito.",
    "tests": "O alvo faz Tolerância (Endurance) oposta à rolagem original de ataque. Se vencer, evita o atordoamento."
  },
  {
    "name": "Agarrar o Inimigo",
    "offense": true,
    "defense": false,
    "critical": false,
    "description": "Com uma mão livre ou apêndice equivalente, segure um alvo ao alcance de combate Desarmado. Ele não consegue se afastar enquanto permanecer agarrado.",
    "tests": "No próprio turno, o alvo pode gastar 1 Ponto de Ação e tentar uma disputa de Força Bruta (Brawn) ou Desarmado contra quem o segura; quem agarra determina qual das duas perícias será usada."
  },
  {
    "name": "Precisão de um Atirador",
    "offense": true,
    "defense": false,
    "critical": false,
    "description": "Em um ataque à distância, desloque o local sorteado do acerto em um passo para uma região adjacente. O efeito pode ser escolhido novamente para mover mais um passo por escolha. Não muda o resultado do ataque para qualquer local desejado. Não exige teste adicional."
  },
  {
    "name": "Ficar de Pé",
    "offense": false,
    "defense": true,
    "critical": false,
    "description": "Se estiver caído, aproveite a abertura criada pela defesa para se levantar imediatamente, inclusive enquanto estiver engajado em combate corpo a corpo. Não exige ação de movimento nem novo teste."
  },
  {
    "name": "Empurrar o Adversário",
    "offense": true,
    "defense": false,
    "critical": false,
    "description": "Empurre o alvo 1 m para cada 2 pontos do dano rolado com escudo ou Força Aprimorada; com outros ataques Desarmados ou Concussivos, 1 m para cada 3 pontos. Use o dano antes de armadura ou bloqueio. Só funciona contra alvos de até o dobro do TAM de quem ataca.",
    "tests": "Se colidir com um obstáculo, o alvo faz Atletismo ou Acrobacia em dificuldade Difícil para não cair."
  },
  {
    "name": "Escolher o Local",
    "offense": true,
    "defense": false,
    "critical": false,
    "description": "Escolha diretamente o local do corpo atingido pelo golpe, desde que esteja ao alcance. Em ataques à distância, só pode ser aplicado com acerto Crítico, conforme a regra do Gemini Force. Não exige novo teste."
  },
  {
    "name": "Danificar um Item",
    "offense": true,
    "defense": true,
    "critical": false,
    "description": "Em um ataque ou defesa, direcione o dano da arma a um objeto carregado ou empunhado pelo adversário em vez de ferir o próprio alvo. Subtraia os Pontos de Armadura do item e reduza seus Pontos de Vida; ao chegar a zero, ele é destruído. Armadura vestida requer arma com a propriedade adequada para danificá-la. Não há teste adicional."
  },
  {
    "name": "Causar uma Distração",
    "offense": true,
    "defense": true,
    "critical": false,
    "description": "Intimide, provoque ou engane o oponente durante o ataque ou defesa. Se ele cair na distração, o próximo teste que fizer como parte de uma ação ou reação fica um grau de dificuldade mais difícil.",
    "tests": "Quem distrai rola Enganação, Influência ou Intimidação como ação livre; o alvo opõe Intuição (Insight). Com um Poder, use o teste indicado pelo Poder; na ausência dele, Atletismo para manifestações físicas ou Vontade para mentais."
  },
  {
    "name": "Derrubar o Oponente",
    "offense": true,
    "defense": true,
    "critical": false,
    "description": "Derrube o adversário para deixá-lo caído. Pode ser escolhido em ataque ou defesa, respeitando a distância e a possibilidade física de alcançar o alvo.",
    "tests": "O alvo escolhe Força Bruta (Brawn), Evasão ou Acrobacia e faz teste oposto à rolagem original de quem aplicou o efeito. Se perder, cai. Alvos com mais de duas pernas podem usar Atletismo com um grau de facilidade."
  },
  {
    "name": "Desarmar Oponente",
    "offense": true,
    "defense": true,
    "critical": false,
    "description": "Arranque ou golpeie o item empunhado pelo alvo. Se o desarme funcionar, ele cai aos pés do alvo quando o Modificador de Dano de quem desarma não for positivo, ou é lançado a uma distância em metros equivalente ao resultado desse modificador. Com uma mão livre e ataque ou defesa Desarmado, é possível tomar a arma em vez de lançá-la. Exige alvo com até o dobro do TAM de quem desarma.",
    "tests": "O alvo faz Estilo de Combate oposto à rolagem original de ataque ou defesa. A resistência fica um grau mais difícil se a arma desarmante for maior, ou um grau mais fácil se for menor."
  },
  {
    "name": "Retomar Cobertura",
    "offense": true,
    "defense": true,
    "critical": false,
    "description": "Volte imediatamente para trás de uma cobertura que já estava usando e que ainda esteja adjacente. Não consome ação de movimento nem exige teste adicional."
  },
  {
    "name": "Emaranhar um Local",
    "offense": true,
    "defense": true,
    "critical": false,
    "description": "Com arma de emaranhamento ou Poder capaz de prender, imobilize o local atingido. Braço preso não usa o que segura; perna presa impede movimento; cabeça, peito ou abdômen presos tornam os testes um grau mais difíceis. No turno seguinte, quem mantém a imobilização pode gastar 1 Ponto de Ação para tentar Derrubar automaticamente.",
    "tests": "Para escapar, o alvo gasta 1 Ponto de Ação e disputa Força Bruta (Brawn) com quem o prendeu; também pode danificar ou desarmar o objeto que o prende."
  },
  {
    "name": "Golpes Múltiplos",
    "offense": true,
    "defense": false,
    "critical": false,
    "description": "Gaste 1 Ponto de Ação para fazer imediatamente outro ataque Desarmado com uma parte do corpo diferente da usada no golpe anterior. O ataque extra ocorre no mesmo turno e pode vir após um golpe inicial com arma.",
    "tests": "Quem executa rola normalmente o ataque Desarmado adicional; o defensor pode reagir conforme as regras usuais de combate."
  },
  {
    "name": "Golpe de Impacto",
    "offense": true,
    "defense": false,
    "critical": false,
    "description": "Role duas vezes o dano básico da arma, ataque Desarmado ou Poder e fique com o maior resultado. O Modificador de Dano não é rolado duas vezes; aplique-o normalmente após escolher o melhor dano básico."
  },
  {
    "name": "Causar Restrição",
    "offense": true,
    "defense": false,
    "critical": false,
    "description": "Com arma de fogo automática em ataque à distância, force o inimigo a se abrigar ou permanecer coberto. Mesmo que o disparo não cause dano, se o efeito vencer o alvo não poderá atacar no próximo turno; ele ainda pode se mover protegido, recarregar ou praticar outras ações.",
    "tests": "O alvo faz Vontade oposta à rolagem original do ataque à distância. Se vencer, evita a Restrição."
  },
  {
    "name": "Pressionar Vantagem",
    "offense": true,
    "defense": true,
    "critical": false,
    "description": "Mantenha o adversário na defensiva ou provoque uma abertura: ele não pode realizar uma Ação de Ataque no próximo turno. Continua livre para defender, movimentar-se ou executar outras ações permitidas. Não há teste adicional."
  },
  {
    "name": "Recarga Rápida",
    "offense": true,
    "defense": false,
    "critical": false,
    "description": "Em arma com tempo de recarga, reduza em um turno a preparação do próximo disparo para cada vez que escolher este efeito. Pode ser aplicado várias vezes na mesma troca. Se chegar a zero, recarregar passa a ser uma ação livre. Não há teste adicional."
  },
  {
    "name": "Stand Fast",
    "offense": false,
    "defense": true,
    "critical": false,
    "description": "Firme sua posição ao defender para ignorar o recuo ou a Pancada (Bash) causada pelo ataque recebido. Aplica-se ao deslocamento forçado; não remove por si só o dano do golpe. Não exige teste adicional."
  },
  {
    "name": "Bater em Retirada",
    "offense": true,
    "defense": true,
    "critical": false,
    "description": "Aproveite a abertura no combate para fazer um deslocamento rápido para longe do oponente, sem precisar rolar para desengajar. Este efeito não amplia o alcance normal do deslocamento."
  },
  {
    "name": "Contornar a Defesa",
    "offense": true,
    "defense": false,
    "critical": true,
    "description": "Em ataque Crítico, escolha uma proteção para superar: ignore a armadura do local atingido, ignore a cobertura alcançável ou trate uma Esquiva/Bloqueio bem-sucedido como falho. Se a cobertura não puder ser atravessada de modo plausível, um disparo de precisão pode contorná-la, mas o dano é rolado duas vezes e fica o menor."
  },
  {
    "name": "Aprimorar Defesa",
    "offense": false,
    "defense": true,
    "critical": true,
    "description": "Após uma defesa Crítica, escolha: bloquear integralmente o ataque apesar do tamanho/Força da arma inimiga; preparar um contra-ataque que anula, pelo restante do combate, um Efeito Especial específico usado por esse adversário e devolve um efeito comum; ou libertar-se automaticamente de agarramento/emaranhamento sem gastar Ponto de Ação."
  },
  {
    "name": "Forçar Falha do Oponente",
    "offense": true,
    "defense": true,
    "critical": true,
    "description": "Quando o oponente sofre um Fumble, combine este efeito com outro Efeito Especial que normalmente permite resistência por teste oposto. A resistência do oponente contra o efeito combinado falha automaticamente, seja a vantagem obtida em ataque ou defesa."
  },
  {
    "name": "Maximizar Dano",
    "offense": true,
    "defense": false,
    "critical": true,
    "description": "Em um ataque Crítico, um dado do dano básico da arma ou do Poder assume automaticamente o seu valor máximo; role os demais dados normalmente. Pode repetir o efeito para maximizar outros dados do mesmo ataque, mas não os dados do Modificador de Dano."
  },
  {
    "name": "Selecionar Alvo",
    "offense": false,
    "defense": true,
    "critical": true,
    "description": "Quando o atacante sofre um Fumble, desvie o ataque para outro alvo: em combate corpo a corpo, ele deve estar adjacente e ao alcance da arma; à distância, deve estar na linha de tiro original. O novo alvo é atingido automaticamente, sofre dano normal e o golpe não gera Efeitos Especiais. Se plausível, o próprio atacante pode ser atingido em um local aleatório."
  }
];
