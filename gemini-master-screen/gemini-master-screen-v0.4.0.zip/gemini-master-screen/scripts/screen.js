import { rules } from "../data/rules.js";
import { renderEffectCard } from "./effect-card.js";

export const SECTIONS = [
  { id: "overview", label: "Visão geral", kicker: "Ponto de partida", icon: "fa-layer-group", description: "Tempo, sorte e dificuldade à mão." },
  { id: "combat", label: "Combate & dano", kicker: "Resposta imediata", icon: "fa-shield-halved", description: "Ferimentos e consequências de cada golpe." },
  { id: "effects", label: "Efeitos especiais", kicker: "24 manobras", icon: "fa-burst", description: "Ofensivos, defensivos e críticos." },
  { id: "tenacity", label: "Tenacidade", kicker: "Horror e trauma", icon: "fa-brain", description: "Intensidades, perdas e condições." },
  { id: "sequelae", label: "Sequelas", kicker: "1d100", icon: "fa-heart-crack", description: "Consequências vitais pós-sobrevivência." },
  { id: "conditions", label: "Fadiga & veículos", kicker: "Desgaste", icon: "fa-gauge-high", description: "Estados de fadiga e acidentes." },
  { id: "calculators", label: "Calculadoras", kicker: "Ferramentas", icon: "fa-calculator", description: "Empurrão, modificador e queda." }
];

const esc = value => String(value ?? "").replace(/[&<>"']/g, ch => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
})[ch]);
const fold = value => String(value).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pt-BR");
const icon = name => `<i class="fa-solid ${name}" aria-hidden="true"></i>`;
const rowList = (items, modifier = "") => `<div class="gf-s-list ${modifier}">${items.map(([label, val]) =>
  `<div class="gf-s-list-row"><span>${esc(label)}</span><strong>${esc(val)}</strong></div>`).join("")}</div>`;

export function modifier(total) {
  if (typeof total === "number") {
    if (!Number.isSafeInteger(total)) return "—";
    total = BigInt(total);
  }
  if (typeof total !== "bigint" || total <= 0n) return "—";
  if (total <= 5n) return "−1d8";
  if (total <= 10n) return "−1d6";
  if (total <= 15n) return "−1d4";
  if (total <= 20n) return "−1d2";
  if (total <= 25n) return "0";
  if (total <= 30n) return "+1d2";
  if (total <= 35n) return "+1d4";
  if (total <= 40n) return "+1d6";
  if (total <= 45n) return "+1d8";
  if (total <= 50n) return "+1d10";
  if (total <= 60n) return "+1d12";
  if (total <= 70n) return "+2d6";
  if (total <= 80n) return "+1d8+1d6";
  if (total <= 90n) return "+2d8";
  if (total <= 100n) return "+1d10+1d8";
  // Destined: after +2d10 at 101–110, each band of 10 adds one die step;
  // every fifth step completes another d10. BigInt avoids an artificial cap.
  const step = (total - 101n) / 10n;
  const tens = 2n + step / 5n;
  const remainder = step % 5n;
  return `+${tens}d10${remainder ? `+1d${remainder * 2n}` : ""}`;
}

export function damageTotal(strength, size, constitution = 0n, mode = "none") {
  if (mode === "none") return strength + size;
  if (mode === "half") return strength + size + (constitution + 1n) / 2n;
  if (mode === "full") return strength + size + constitution;
  throw new Error("Modo de CON inválido.");
}

export function fall(height) {
  if (!Number.isFinite(height) || height <= 0) return { damage: "—", places: "—" };
  const dice = height <= 1 ? 1 : height <= 5 ? 2 : height <= 10 ? 3 :
    height <= 15 ? 4 : height <= 20 ? 5 : 5 + Math.floor((height - 20) / 5);
  const places = Math.min(dice, 7);
  return { damage: `${dice}d6`, places: `${places} ${places === 1 ? "local" : "locais"}` };
}

export function matchRange(roll, range) {
  if (!Number.isInteger(roll) || !range) return false;
  if (!range.includes("-")) return roll === Number(range === "00" ? 100 : range);
  const [start, end] = range.split("-").map(value => Number(value === "00" ? 100 : value));
  return roll >= start && roll <= end;
}

const panel = (title, body, meta = "") => `<section class="gf-s-panel"><div class="gf-s-panel-head"><h3>${esc(title)}</h3>${meta}</div>${body}</section>`;
const table = (source, key, options = {}) => `<div class="gf-s-table-wrap"><table class="gf-s-table" aria-label="${esc(options.title || key)}">
  <thead><tr>${source.headers.map(head => `<th scope="col">${esc(head)}</th>`).join("")}</tr></thead>
  <tbody>${source.rows.map((row, index) => `<tr id="gf-s-${key}-${index}" ${row.range ? `data-row="${key}:${index}" tabindex="0" title="Ver detalhe"` : ""}>
  ${row.cells.map((cell, col) => `<td ${col === 0 ? 'class="gf-s-first"' : ""}${row.colspans?.[col] > 1 ? ` colspan="${row.colspans[col]}"` : ""}>${esc(cell)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;

const NAV = Object.fromEntries(SECTIONS.map(section => [section.id, section]));

export class MasterScreen {
  constructor(root, { rollDie, storageKey = "gemini-master-screen:favorites", welcomeKey = "gemini-master-screen:welcome:v1", welcomeName = "Mestre" } = {}) {
    if (typeof game !== "undefined" && !game.user?.isGM) throw new Error("O Escudo completo é exclusivo dos Mestres.");
    this.root = root;
    this.rollDie = rollDie || (async sides => {
      const bytes = new Uint32Array(1);
      const limit = Math.floor(2 ** 32 / sides) * sides;
      do { crypto.getRandomValues(bytes); } while (bytes[0] >= limit);
      return bytes[0] % sides + 1;
    });
    this.storageKey = storageKey;
    this.welcomeKey = welcomeKey;
    this.welcomeName = String(welcomeName || "Mestre").trim() || "Mestre";
    this.tab = "overview";
    this.filter = "all";
    this.favorites = this.readFavorites();
    this.lastRoll = null;
    this.searchEntries = this.indexRules();
    this.results = [];
    this.searchPosition = 0;
    this.keyHandler = event => {
      if (this.welcomeOpen()) {
        if (event.key === "Escape") { event.preventDefault(); this.dismissWelcome(); }
        return;
      }
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault(); this.root.querySelector(".gf-s-search-input")?.focus();
      }
      if (event.key === "Escape") { this.hideSearch(); this.closeOverlay(); }
    };
    document.addEventListener("keydown", this.keyHandler);
    this.mount();
  }

  destroy() { document.removeEventListener("keydown", this.keyHandler); }

  readFavorites() {
    try {
      const ids = JSON.parse(localStorage.getItem(this.storageKey) || "[]");
      return new Set(Array.isArray(ids) ? ids.filter(id => Number.isInteger(id) && id >= 0 && id < rules.effects.length) : []);
    } catch { return new Set(); }
  }

  indexRules() {
    const entries = [];
    const add = (tab, title, detail, target) => entries.push({ tab, title, detail, target,
      searchable: fold(`${title} ${detail} ${NAV[tab].label}`) });
    for (const [index, effect] of rules.effects.entries()) {
      const tags = [effect.critical && "Crítico", effect.offense && "Ofensivo", effect.defense && "Defensivo"].filter(Boolean).join(" · ");
      add("effects", effect.name, `${tags} ${effect.description} ${effect.tests || ""}`, `gf-s-effect-${index}`);
    }
    for (const [index, injury] of rules.injuries.entries()) add("combat", injury.name, injury.details.join(" "), `gf-s-injury-${index}`);
    for (const [key, tab] of [["immediate", "tenacity"], ["delayed", "tenacity"], ["sequelae", "sequelae"], ["fatigue", "conditions"], ["accidents", "conditions"], ["success", "overview"]]) {
      const source = key === "success" ? rules.overview.success : rules[key];
      source.rows.forEach((row, index) => add(tab, row.cells[1] || row.cells[0], row.cells.join(" · "), `gf-s-${key}-${index}`));
    }
    for (const [index, loss] of rules.loss.entries()) add("tenacity", loss.name, loss.description, `gf-s-loss-${index}`);
    for (const [index, row] of rules.overview.difficulty.entries()) add("overview", row[0], row.join(" · "), `gf-s-difficulty-${index}`);
    add("calculators", "Modificador de Dano", "FOR TAM CON metade CON inteira dado bônus penalidade", "gf-s-calculator-mod");
    add("calculators", "Dano de Queda", "Metros d6 locais", "gf-s-calculator-fall");
    add("calculators", "Pancada Bash", "Distância de empurrão escudo força dano", "gf-s-calculator-bash");
    return entries;
  }

  mount() {
    this.root.classList.add("gf-shield");
    this.root.innerHTML = `<aside class="gf-s-side">
      <div class="gf-s-brand"><div class="gf-s-mark">${icon("fa-shield-halved")}</div><div><strong>GEMINI <span>FORCE</span></strong><small>MASTER SYSTEM / 01</small></div></div>
      <div class="gf-s-side-label">NAVEGAÇÃO</div><nav class="gf-s-nav" aria-label="Áreas do Escudo">
      ${SECTIONS.map(section => `<button type="button" class="gf-s-nav-item" data-tab="${section.id}" title="${esc(section.label)}">${icon(section.icon)}<span>${esc(section.label)}</span>${section.id === "effects" ? `<small>${rules.effects.length}</small>` : ""}</button>`).join("")}</nav>
      <div class="gf-s-side-foot"><div class="gf-s-online-dot"></div><div>ARQUIVO DE CAMPO<small>Acesso restrito ao Mestre</small></div></div>
    </aside><div class="gf-s-workspace"><header class="gf-s-topbar">
      <div class="gf-s-breadcrumb">GEMINI FORCE <span>/</span> ESCUDO DO MESTRE <span>/</span> <strong class="gf-s-breadcrumb-current">VISÃO GERAL</strong></div>
      <div class="gf-s-top-actions"><label class="gf-s-search">${icon("fa-magnifying-glass")}<input class="gf-s-search-input" type="search" aria-label="Buscar regras e efeitos" placeholder="Buscar regra, efeito, dano..." autocomplete="off"><kbd>Ctrl K</kbd></label><div class="gf-s-search-results" hidden></div>
        <button type="button" class="gf-s-icon-button" data-tab="calculators" title="Abrir calculadoras" aria-label="Abrir calculadoras">${icon("fa-calculator")}</button></div>
    </header><div class="gf-s-scroll"><div class="gf-s-main"><div class="gf-s-page"></div><footer class="gf-s-footer">GEMINI FORCE <span>•</span> Escudo de consulta <span>•</span> Dados baseados no material fornecido pelo projeto</footer></div></div></div>
    <div class="gf-s-overlay" hidden><div class="gf-s-overlay-scrim" data-close="overlay"></div><div class="gf-s-overlay-card" role="dialog" aria-modal="true"><button type="button" data-close="overlay" aria-label="Fechar" class="gf-s-overlay-close">${icon("fa-xmark")}</button><div class="gf-s-overlay-content"></div></div></div>
    <div class="gf-s-welcome" hidden><section class="gf-s-welcome-card" role="dialog" aria-modal="true" aria-labelledby="gf-s-welcome-title" aria-describedby="gf-s-welcome-description">
      <div class="gf-s-welcome-symbol" aria-hidden="true">${icon("fa-shield-halved")}</div>
      <span class="gf-s-eyebrow">GEMINI FORCE <span class="gf-s-welcome-divider">/</span> ACESSO DO MESTRE</span>
      <h2 id="gf-s-welcome-title">Bem-vindo, Mestre<span>${esc(this.welcomeName)}</span></h2>
      <p id="gf-s-welcome-description">O escudo está pronto para a sua mesa. Encontre regras, resolva efeitos e continue a história sem perder o ritmo.</p>
      <div class="gf-s-welcome-features"><span>${icon("fa-magnifying-glass")} Busca rápida</span><span>${icon("fa-dice-d20")} Tabelas</span><span>${icon("fa-calculator")} Cálculos</span></div>
      <button type="button" class="gf-s-button primary gf-s-welcome-enter" data-enter>Entrar no escudo ${icon("fa-arrow-right")}</button>
      <small>Apenas Mestres podem acessar este espaço.</small>
    </section></div>`;
    this.root.addEventListener("click", event => this.handleClick(event));
    this.root.addEventListener("input", event => this.handleInput(event));
    this.root.addEventListener("change", event => this.handleInput(event));
    this.root.addEventListener("keydown", event => this.handleKey(event));
    this.renderPage();
    this.showWelcome();
  }

  welcomeOpen() { return !this.root.querySelector(".gf-s-welcome")?.hidden; }

  showWelcome() {
    let seen = false;
    try { seen = localStorage.getItem(this.welcomeKey) === "1"; } catch { /* Continue without persistent storage. */ }
    if (seen) return;
    this.root.querySelector(".gf-s-welcome").hidden = false;
    this.root.querySelector(".gf-s-side").inert = true;
    this.root.querySelector(".gf-s-workspace").inert = true;
    this.root.querySelector(".gf-s-welcome-enter").focus();
  }

  dismissWelcome() {
    const welcome = this.root.querySelector(".gf-s-welcome");
    if (!welcome || welcome.hidden) return;
    welcome.hidden = true;
    this.root.querySelector(".gf-s-side").inert = false;
    this.root.querySelector(".gf-s-workspace").inert = false;
    try { localStorage.setItem(this.welcomeKey, "1"); } catch { /* Acesso continua sem armazenamento. */ }
    this.root.querySelector(".gf-s-search-input")?.focus();
  }

  navigate(tab, target) {
    if (!NAV[tab]) return;
    this.tab = tab;
    if (tab === "effects" && target?.startsWith("gf-s-effect-")) this.filter = "all";
    this.hideSearch();
    this.renderPage();
    this.root.querySelector(".gf-s-scroll").scrollTop = 0;
    if (target) requestAnimationFrame(() => {
      const el = this.root.querySelector(`#${target}`);
      if (el) {
        el.scrollIntoView({ block: "center", behavior: "smooth" });
        el.classList.add("gf-s-flash");
        setTimeout(() => el.classList.remove("gf-s-flash"), 1700);
      }
    });
  }

  renderPage() {
    const section = NAV[this.tab];
    this.root.querySelector(".gf-s-breadcrumb-current").textContent = section.label.toUpperCase();
    for (const nav of this.root.querySelectorAll("[data-tab].gf-s-nav-item")) {
      const selected = nav.dataset.tab === this.tab;
      nav.classList.toggle("is-active", selected);
      nav.setAttribute("aria-current", selected ? "page" : "false");
    }
    this.root.querySelector(".gf-s-page").innerHTML = `<div class="gf-s-page-intro"><div><span class="gf-s-eyebrow">${esc(section.kicker)} <span class="gf-s-spark">✦</span> GM REFERENCE</span><h1>${esc(section.label)}</h1><p>${esc(section.description)}</p></div>
      <div class="gf-s-intro-label">GF <span>/</span> ${String(SECTIONS.indexOf(section) + 1).padStart(2, "0")}</div></div>${this.renderContent()}`;
    this.updateCalculators();
  }

  renderContent() {
    if (this.tab === "overview") return this.overview();
    if (this.tab === "combat") return this.combat();
    if (this.tab === "effects") return this.effects();
    if (this.tab === "tenacity") return this.tenacity();
    if (this.tab === "sequelae") return this.sequelae();
    if (this.tab === "conditions") return this.conditions();
    return this.calculators();
  }

  overview() {
    const pinned = [...this.favorites].sort((a, b) => a - b);
    return `<div class="gf-s-hero gf-s-glass"><div class="gf-s-hero-copy"><span class="gf-s-eyebrow">SUA MESA, EM CONTROLE</span><h2>Encontre a regra.<br><em>Mantenha o ritmo.</em></h2><p>Referências essenciais e resoluções em poucos cliques. O escudo trabalha enquanto a história acontece.</p>
      <div class="gf-s-hero-actions"><button type="button" class="gf-s-button primary" data-tab="effects">${icon("fa-burst")} Ver efeitos especiais</button><button type="button" class="gf-s-button subtle" data-tab="calculators">Abrir calculadoras ${icon("fa-arrow-up-right-from-square")}</button></div></div>
      <div class="gf-s-hero-art" aria-hidden="true"><div class="gf-s-orbit one"></div><div class="gf-s-orbit two"></div><div class="gf-s-orbit three"></div><div class="gf-s-hero-glyph">✦</div><span class="gf-s-orbit-node a"></span><span class="gf-s-orbit-node b"></span></div></div>
      <div class="gf-s-stat-grid"><div class="gf-s-stat gf-s-glass"><span>${icon("fa-clock")} RODADA</span><strong>05 <small>segundos</small></strong><em>Tempo de combate</em></div><div class="gf-s-stat gf-s-glass"><span>${icon("fa-dice-d20")} EFEITOS</span><strong>${rules.effects.length} <small>manobras</small></strong><em>Normais e críticos</em></div><div class="gf-s-stat gf-s-glass"><span>${icon("fa-table-list")} CONSULTA</span><strong>06 <small>tabelas</small></strong><em>Prontas para a mesa</em></div></div>
      <div class="gf-s-section-heading"><div><span class="gf-s-eyebrow">NO CALOR DA CENA</span><h2>Acesso rápido</h2></div></div>
      <div class="gf-s-shortcuts">${[["combat", "fa-heart-pulse", "Ferimentos", "Leve, sério e persistente"],["tenacity", "fa-brain", "Tenacidade", "Horror e condições"],["sequelae", "fa-dice-d20", "Sequelas", "Role na tabela"],["conditions", "fa-car-burst", "Veículos", "Acidentes e fadiga"]].map(([tab, glyph, label, detail]) => `<button type="button" data-tab="${tab}" class="gf-s-shortcut gf-s-glass">${icon(glyph)}<strong>${label}</strong><small>${detail}</small>${icon("fa-arrow-right")}</button>`).join("")}</div>
      <div class="gf-s-section-heading"><div><span class="gf-s-eyebrow">REGRAS CENTRAIS</span><h2>Ao alcance dos olhos</h2></div></div>
      <div class="gf-s-overview-grid">${panel("Tempo & turnos", rowList(rules.overview.time), `<span class="gf-s-panel-icon">${icon("fa-stopwatch")}</span>`)}
        ${panel("Uso de Sorte", `<ul class="gf-s-bullet-list">${rules.overview.luck.map(item => `<li>${esc(item)}</li>`).join("")}</ul>`, `<span class="gf-s-panel-icon">${icon("fa-clover")}</span>`)}
        ${panel("Dificuldades", `<div class="gf-s-list">${rules.overview.difficulty.map(([label, val], index) => `<div id="gf-s-difficulty-${index}" class="gf-s-list-row"><span>${esc(label)}</span><strong>${esc(val)}</strong></div>`).join("")}</div>`, `<span class="gf-s-panel-icon">${icon("fa-sliders")}</span>`)}</div>
      ${panel("Níveis de sucesso", table(rules.overview.success, "success", {title:"Níveis de sucesso"}), `<span class="gf-s-panel-meta">D100 / PERÍCIA</span>`)}
      ${pinned.length ? `<div class="gf-s-section-heading"><div><span class="gf-s-eyebrow">SALVOS NO NAVEGADOR</span><h2>Efeitos fixados</h2></div><button type="button" data-tab="effects" class="gf-s-text-link">Ver todos ${icon("fa-arrow-right")}</button></div><div class="gf-s-effect-grid">${pinned.map(index => renderEffectCard(rules.effects[index], index, true)).join("")}</div>` : ""}`;
  }

  combat() {
    return `<div class="gf-s-callout"><span>${icon("fa-bolt")}</span><div><strong>Precisou resolver um golpe?</strong><p>Confira o grau de ferimento abaixo e abra os efeitos especiais sem perder a cena.</p></div><button type="button" class="gf-s-button subtle" data-tab="effects">Ver manobras ${icon("fa-arrow-right")}</button></div>
      <div class="gf-s-injury-grid">${rules.injuries.map((injury, index) => `<article id="gf-s-injury-${index}" class="gf-s-injury gf-s-glass tone-${index}"><span class="gf-s-injury-step">0${index + 1} / ESTADO</span><h2>${esc(injury.name)}</h2><ul>${injury.details.map(detail => `<li>${esc(detail)}</li>`).join("")}</ul></article>`).join("")}</div>
      <div class="gf-s-danger"><span>${icon("fa-triangle-exclamation")}</span><div><strong>Regra: dano grave na cabeça</strong><p>${esc(rules.headWarning.replace(/^Regra: Dano Grave na Cabeça\s*/, ""))}</p></div></div>
      <div class="gf-s-section-heading"><div><span class="gf-s-eyebrow">RESOLVA O IMPACTO</span><h2>Da regra ao cálculo</h2></div></div>
      <div class="gf-s-shortcuts">${[["gf-s-calculator-bash", "Empurrão", "Dano e tipo de ataque"],["gf-s-calculator-mod", "Modificador", "FOR + TAM + CON opcional"],["gf-s-calculator-fall", "Queda", "Metros e locais"]].map(([target, label, detail]) => `<button type="button" class="gf-s-shortcut gf-s-glass" data-tab="calculators" data-target="${target}">${icon("fa-calculator")}<strong>${label}</strong><small>${detail}</small>${icon("fa-arrow-right")}</button>`).join("")}</div>`;
  }

  effects() {
    const filters = [["all", "Todos"],["offense", "Ofensivos"],["defense", "Defensivos"],["critical", "Críticos"],["pinned", "Fixados"]];
    const visible = rules.effects.map((effect, index) => ({ effect, index })).filter(({effect, index}) =>
      this.filter === "all" || (this.filter === "pinned" ? this.favorites.has(index) : Boolean(effect[this.filter])));
    return `<div class="gf-s-toolbar gf-s-glass"><div><strong>${visible.length} efeitos</strong><small>Escolha o momento, encontre a manobra.</small></div><div class="gf-s-filters" role="group" aria-label="Filtrar efeitos">${filters.map(([id, label]) => `<button type="button" data-filter="${id}" class="${id === this.filter ? "is-selected" : ""}" aria-pressed="${id === this.filter}">${label}${id === "pinned" ? ` <span>${this.favorites.size}</span>` : ""}</button>`).join("")}</div></div>
      <div class="gf-s-effect-grid">${visible.map(({effect,index}) => renderEffectCard(effect, index, this.favorites.has(index))).join("") || `<p class="gf-s-empty">Ainda não há efeitos fixados. Use a estrela em um card para guardá-lo aqui e na visão geral.</p>`}</div>`;
  }

  tenacity() {
    return `${panel("Intensidade do horror", `<div class="gf-s-intensity">${rules.intensity.map(([level, effect]) => `<div><span>${esc(level)}</span><strong>${esc(effect)}</strong></div>`).join("")}</div><div class="gf-s-panel-note">${rules.intensityNotes.map(esc).join("<br>")}</div>`, `<span class="gf-s-panel-meta">0 — 4</span>`)}
      <div class="gf-s-section-heading"><div><span class="gf-s-eyebrow">DADOS / RESOLUÇÃO</span><h2>Condições de trauma</h2></div></div>
      ${this.rollPanel("Condições imediatas", "immediate", "1d20", "Medo, horror e loucura / psiônico")}
      ${this.rollPanel("Condições adiadas", "delayed", "1d20", "Consequências prolongadas")}
      <div class="gf-s-section-heading"><div><span class="gf-s-eyebrow">PERDA DE TENACIDADE</span><h2>Limiar e efeito</h2></div></div>
      <div class="gf-s-loss-grid">${rules.loss.map((item,index) => `<div id="gf-s-loss-${index}" class="gf-s-loss gf-s-glass"><small>0${index+1} / LIMIAR</small><strong>${esc(item.name)}</strong><p>${esc(item.description)}</p></div>`).join("")}</div>`;
  }

  rollPanel(title, key, dice, note) {
    return panel(title, `<p class="gf-s-table-note">${esc(note)}. Clique em uma linha para ampliar os detalhes.</p>${table(rules[key], key, {title})}`,
      `<button type="button" class="gf-s-button roll" data-roll="${key}">${icon("fa-dice-d20")} Rolar ${dice}</button>`);
  }

  sequelae() { return `<div class="gf-s-callout"><span>${icon("fa-heart-pulse")}</span><div><strong>Consequências vitais</strong><p>Vinte resultados para ferimentos em zonas vitais. 00 representa o resultado 100 no d100.</p></div></div>${this.rollPanel("Sequelas pós-sobrevivência", "sequelae", "1d100", "Efeito e descrição")}`; }

  conditions() { return `${panel("Níveis de fadiga", `<p class="gf-s-table-note">Do estado ileso à incapacitação. Deslize horizontalmente em janelas estreitas.</p>${table(rules.fatigue, "fatigue", {title:"Níveis de fadiga"})}`, `<span class="gf-s-panel-meta">9 ESTADOS</span>`)}
    ${this.rollPanel("Perda de controle do veículo", "accidents", "1d100", "Resultado e efeito do acidente")}`; }

  calculators() { return `<div class="gf-s-calculator-grid">
    <section id="gf-s-calculator-bash" class="gf-s-calc gf-s-glass"><div class="gf-s-calc-icon">${icon("fa-arrow-right-long")}</div><span class="gf-s-eyebrow">01 / COMBATE</span><h2>Empurrão</h2><p>Distância da Pancada (Bash), conforme o dano e o tipo de ataque.</p><label>Dano aplicado<input data-calc="bashDamage" type="number" min="0" step="1" inputmode="numeric" placeholder="Ex.: 12"></label><label>Tipo de ataque<select data-calc="bashDivisor"><option value="3">Arma comum / outros (÷3)</option><option value="2">Escudo / força bruta (÷2)</option></select></label><div class="gf-s-output"><span>DISTÂNCIA</span><strong data-result="bash">—</strong><small>metros de recuo</small></div></section>
    <section id="gf-s-calculator-mod" class="gf-s-calc gf-s-glass"><div class="gf-s-calc-icon">${icon("fa-fist-raised")}</div><span class="gf-s-eyebrow">02 / DANO</span><h2>Modificador</h2><p>Some FOR e TAM. Se o personagem usar CON no cálculo, escolha metade ou valor inteiro.</p><div class="gf-s-calc-pair"><label>FOR<input data-calc="strength" type="text" inputmode="numeric" pattern="[0-9]*" autocomplete="off" placeholder="FOR"></label><label>TAM<input data-calc="size" type="text" inputmode="numeric" pattern="[0-9]*" autocomplete="off" placeholder="TAM"></label></div><label>Adicionar CON<select data-calc="constitutionMode"><option value="none">Sem CON</option><option value="half">Metade da CON</option><option value="full">CON inteira</option></select></label><label class="gf-s-con-field" hidden>CON<input data-calc="constitution" type="text" inputmode="numeric" pattern="[0-9]*" autocomplete="off" placeholder="CON"></label><div class="gf-s-output"><span>DADO BÔNUS / PENALIDADE</span><strong data-result="mod">—</strong><small data-result="sum">FOR + TAM</small></div></section>
    <section id="gf-s-calculator-fall" class="gf-s-calc gf-s-glass"><div class="gf-s-calc-icon">${icon("fa-arrow-down-long")}</div><span class="gf-s-eyebrow">03 / AMBIENTE</span><h2>Dano de queda</h2><p>Dano e quantidade de locais atingidos, até o máximo de sete locais.</p><label>Altura da queda (m)<input data-calc="height" type="number" min="0" step="1" inputmode="numeric" placeholder="Ex.: 8"></label><div class="gf-s-output"><span>DANO / LOCAIS</span><strong data-result="fall">—</strong><small data-result="places">—</small></div></section>
  </div><p class="gf-s-quiet">Os valores seguem o escudo original fornecido pelo projeto. Não substituem uma decisão do Mestre sobre a cena.</p>`; }

  updateCalculators() {
    const get = name => this.root.querySelector(`[data-calc="${name}"]`);
    if (!get("bashDamage")) return;
    const number = name => {
      const field = get(name);
      if (!field || field.value.trim() === "") return null;
      const value = Number(field.value);
      return Number.isFinite(value) && Number.isInteger(value) && value >= 0 ? value : null;
    };
    const damage = number("bashDamage"), divisor = number("bashDivisor");
    this.root.querySelector('[data-result="bash"]').textContent = damage == null || !divisor ? "—" : `${Math.floor(damage / divisor)} m`;
    const mode = get("constitutionMode").value;
    const conField = this.root.querySelector(".gf-s-con-field");
    conField.hidden = mode === "none";
    get("constitution").disabled = mode === "none";
    const whole = name => {
      const input = get(name)?.value.trim();
      return input && /^[0-9]+$/.test(input) ? BigInt(input) : null;
    };
    const str = whole("strength"), size = whole("size"), con = mode === "none" ? 0n : whole("constitution");
    const valid = str != null && size != null && con != null;
    const total = valid ? damageTotal(str, size, con, mode) : null;
    this.root.querySelector('[data-result="mod"]').textContent = total == null ? "—" : modifier(total);
    const part = mode === "none" ? "" : ` + ${mode === "half" ? "½ CON" : "CON"} ${mode === "half" ? (con == null ? "?" : (con + 1n) / 2n) : con ?? "?"}`;
    this.root.querySelector('[data-result="sum"]').textContent = total == null ? `FOR + TAM${mode === "none" ? "" : mode === "half" ? " + ½ CON" : " + CON"}` : `FOR ${str} + TAM ${size}${part} = ${total}`;
    const value = number("height"), result = fall(value);
    this.root.querySelector('[data-result="fall"]').textContent = result.damage;
    this.root.querySelector('[data-result="places"]').textContent = result.places;
  }

  handleInput(event) {
    if (event.target.matches(".gf-s-search-input")) return this.renderSearch(event.target.value);
    if (event.target.matches("[data-calc]")) return this.updateCalculators();
  }

  renderSearch(term) {
    const box = this.root.querySelector(".gf-s-search-results");
    const words = fold(term.trim()).split(/\s+/).filter(Boolean);
    if (!words.length) return this.hideSearch();
    this.results = this.searchEntries.filter(entry => words.every(word => entry.searchable.includes(word)))
      .sort((a, b) => Number(fold(b.title).startsWith(words[0])) - Number(fold(a.title).startsWith(words[0]))).slice(0, 12);
    this.searchPosition = 0;
    box.hidden = false;
    box.innerHTML = `<div class="gf-s-search-head">${this.results.length ? `${this.results.length} RESULTADO(S)` : "NENHUM RESULTADO"} <kbd>ENTER</kbd></div>
      ${this.results.map((entry,index) => `<button type="button" class="gf-s-search-hit ${index === 0 ? "is-focused" : ""}" data-hit="${index}"><span>${esc(NAV[entry.tab].label)}</span><strong>${esc(entry.title)}</strong><small>${esc(entry.detail)}</small></button>`).join("")}
      ${!this.results.length ? '<div class="gf-s-search-none">Tente buscar o nome de um efeito, estado ou cálculo.</div>' : ""}`;
  }

  hideSearch() { const box = this.root.querySelector(".gf-s-search-results"); if (box) box.hidden = true; }

  handleKey(event) {
    if (event.target.matches(".gf-s-search-input")) {
      if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        this.searchPosition = Math.max(0, Math.min(this.results.length - 1, this.searchPosition + (event.key === "ArrowDown" ? 1 : -1)));
        this.root.querySelectorAll(".gf-s-search-hit").forEach((hit, index) => hit.classList.toggle("is-focused", index === this.searchPosition));
      }
      if (event.key === "Enter" && this.results[this.searchPosition]) {
        event.preventDefault(); const entry = this.results[this.searchPosition]; this.navigate(entry.tab, entry.target);
      }
    }
    if (event.key === "Enter" && event.target.matches("tr[data-row]")) event.target.click();
  }

  async handleClick(event) {
    const button = event.target.closest("button,[data-row],[data-close]");
    if (!button || !this.root.contains(button)) { if (!event.target.closest(".gf-s-search")) this.hideSearch(); return; }
    if (button.dataset.enter != null) { this.dismissWelcome(); return; }
    if (button.dataset.close) { this.closeOverlay(); return; }
    if (button.dataset.hit != null) { const entry = this.results[Number(button.dataset.hit)]; if (entry) this.navigate(entry.tab, entry.target); return; }
    if (button.dataset.tab) { this.navigate(button.dataset.tab, button.dataset.target); return; }
    if (button.dataset.filter) { this.filter = button.dataset.filter; this.renderPage(); return; }
    if (button.dataset.pin != null) {
      const index = Number(button.dataset.pin);
      this.favorites.has(index) ? this.favorites.delete(index) : this.favorites.add(index);
      try { localStorage.setItem(this.storageKey, JSON.stringify([...this.favorites])); } catch { /* Browsers with storage disabled still work. */ }
      this.renderPage(); return;
    }
    if (button.dataset.roll) { await this.rollTable(button.dataset.roll); return; }
    if (button.dataset.reroll) { await this.rollTable(button.dataset.reroll); return; }
    if (button.dataset.row) { const [key, index] = button.dataset.row.split(":"); this.showRow(key, Number(index)); }
  }

  async rollTable(key) {
    const sides = key === "immediate" || key === "delayed" ? 20 : 100;
    try {
      const value = await this.rollDie(sides);
      if (!Number.isInteger(value) || value < 1 || value > sides) throw new Error("Resultado inválido da rolagem.");
      const index = rules[key].rows.findIndex(row => matchRange(value, row.range));
      if (index < 0) throw new Error("Não há resultado para esta rolagem na tabela.");
      this.lastRoll = { key, index, value, sides };
      this.showRow(key, index, this.lastRoll);
      this.root.querySelectorAll(`[data-row^="${key}:"]`).forEach(row => row.classList.remove("is-rolled"));
      this.root.querySelector(`[data-row="${key}:${index}"]`)?.classList.add("is-rolled");
    } catch (error) { this.notify(error.message || String(error)); }
  }

  showRow(key, index, roll = null) {
    const row = rules[key]?.rows[index];
    if (!row) return;
    const label = { immediate: "Condição imediata", delayed: "Condição adiada", sequelae: "Sequela vital", fatigue: "Estado de fadiga", accidents: "Acidente", success: "Nível de sucesso" }[key] || "Detalhe";
    const cells = row.cells;
    const title = cells.length >= 3 ? cells[1] : cells[0];
    const value = roll ? String(roll.value === 100 ? "00" : roll.value).padStart(roll.sides === 100 ? 2 : 1, "0") : "";
    const content = `<span class="gf-s-eyebrow">${esc(label.toUpperCase())} ${row.range ? ` / ${esc(row.range)}` : ""}</span>
      ${roll ? `<div class="gf-s-roll-number">${value}</div><span class="gf-s-roll-caption">RESULTADO DA ROLAGEM • PRIVADO</span>` : ""}
      <h2>${esc(title)}</h2><div class="gf-s-detail-list">${cells.map((cell,i) => `<div><small>${esc(rules[key].headers[i])}</small><p>${esc(cell)}</p></div>`).join("")}</div>
      ${roll ? `<button type="button" class="gf-s-button primary gf-s-reroll" data-reroll="${key}">${icon("fa-dice-d20")} Rolar novamente</button>` : ""}`;
    const overlay = this.root.querySelector(".gf-s-overlay");
    overlay.querySelector(".gf-s-overlay-content").innerHTML = content;
    overlay.hidden = false;
    overlay.querySelector(".gf-s-overlay-close").focus();
  }

  closeOverlay() { this.root.querySelector(".gf-s-overlay").hidden = true; }
  notify(message) { if (typeof ui !== "undefined" && ui.notifications) ui.notifications.error(`Escudo do Mestre: ${message}`); else console.error(message); }
}
