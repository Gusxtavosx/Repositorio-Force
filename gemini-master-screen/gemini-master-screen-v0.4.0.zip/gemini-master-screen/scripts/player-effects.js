import { effects } from "../data/effects.js";
import { renderEffectCard } from "./effect-card.js";

const fold = value => String(value ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pt-BR");
const filters = [["all", "Todos"], ["offense", "Ofensivos"], ["defense", "Defensivos"], ["critical", "Críticos"], ["pinned", "Fixados"]];

/** The player view imports only the public effects catalog, not GM reference data. */
export class PlayerEffectsScreen {
  constructor(root, { storageKey = "gemini-master-screen:player-favorites" } = {}) {
    this.root = root;
    this.storageKey = storageKey;
    this.filter = "all";
    this.query = "";
    this.favorites = this.readFavorites();
    this.keyHandler = event => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        this.root.querySelector(".gf-s-search-input")?.focus();
      }
      if (event.key === "Escape" && this.root.contains(document.activeElement)) {
        this.root.querySelector(".gf-s-search-input").value = "";
        this.query = "";
        this.renderCards();
      }
    };
    document.addEventListener("keydown", this.keyHandler);
    this.mount();
  }

  destroy() { document.removeEventListener("keydown", this.keyHandler); }

  readFavorites() {
    try {
      const data = JSON.parse(localStorage.getItem(this.storageKey) || "[]");
      return new Set(Array.isArray(data) ? data.filter(id => Number.isInteger(id) && id >= 0 && id < effects.length) : []);
    } catch { return new Set(); }
  }

  mount() {
    this.root.classList.add("gf-shield", "gf-s-player");
    this.root.innerHTML = `<aside class="gf-s-side">
      <div class="gf-s-brand"><div class="gf-s-mark"><i class="fa-solid fa-burst" aria-hidden="true"></i></div><div><strong>GEMINI <span>FORCE</span></strong><small>REFERÊNCIA DE COMBATE</small></div></div>
      <div class="gf-s-side-label">CONSULTA</div><nav class="gf-s-nav" aria-label="Área disponível"><span class="gf-s-nav-item is-active" aria-current="page"><i class="fa-solid fa-burst" aria-hidden="true"></i><span>Efeitos especiais</span><small>${effects.length}</small></span></nav>
      <div class="gf-s-side-foot"><div class="gf-s-online-dot"></div><div>EFEITOS ESPECIAIS<small>Consulta para jogadores</small></div></div>
    </aside><div class="gf-s-workspace"><header class="gf-s-topbar">
      <div class="gf-s-breadcrumb">GEMINI FORCE <span>/</span> <strong>EFEITOS ESPECIAIS</strong></div>
      <div class="gf-s-top-actions"><label class="gf-s-search"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i><input class="gf-s-search-input" type="search" aria-label="Buscar efeitos especiais" placeholder="Buscar efeito, teste, mecânica..." autocomplete="off"><kbd>Ctrl K</kbd></label></div>
    </header><div class="gf-s-scroll"><div class="gf-s-main"><div class="gf-s-page-intro"><div><span class="gf-s-eyebrow">REFERÊNCIA DE COMBATE <span class="gf-s-spark">✦</span> GEMINI FORCE</span><h1>Efeitos especiais</h1><p>Encontre a manobra, seus testes e quem precisa fazê-los.</p></div><div class="gf-s-intro-label">GF <span>/</span> 03</div></div>
    <div class="gf-s-toolbar gf-s-glass"><div><strong class="gf-s-player-count"></strong><small>Regras e resistência ao alcance da mesa.</small></div><div class="gf-s-filters" role="group" aria-label="Filtrar efeitos"></div></div>
    <div class="gf-s-effect-grid gf-s-player-grid"></div><footer class="gf-s-footer">GEMINI FORCE <span>•</span> Efeitos especiais</footer></div></div></div>`;
    this.root.addEventListener("click", event => {
      const pin = event.target.closest("[data-pin]");
      if (pin && this.root.contains(pin)) {
        const index = Number(pin.dataset.pin);
        this.favorites.has(index) ? this.favorites.delete(index) : this.favorites.add(index);
        try { localStorage.setItem(this.storageKey, JSON.stringify([...this.favorites])); } catch { /* Works without storage. */ }
        this.renderCards();
        return;
      }
      const filter = event.target.closest("[data-filter]");
      if (filter && this.root.contains(filter)) { this.filter = filter.dataset.filter; this.renderCards(); }
    });
    this.root.querySelector(".gf-s-search-input").addEventListener("input", event => {
      this.query = fold(event.target.value.trim());
      this.renderCards();
    });
    this.renderCards();
  }

  renderCards() {
    this.root.querySelector(".gf-s-filters").innerHTML = filters.map(([id, label]) =>
      `<button type="button" data-filter="${id}" class="${id === this.filter ? "is-selected" : ""}" aria-pressed="${id === this.filter}">${label}${id === "pinned" ? ` <span>${this.favorites.size}</span>` : ""}</button>`).join("");
    const words = this.query.split(/\s+/).filter(Boolean);
    const visible = effects.map((effect, index) => ({ effect, index })).filter(({ effect, index }) => {
      if (this.filter !== "all" && !(this.filter === "pinned" ? this.favorites.has(index) : effect[this.filter])) return false;
      const content = fold(`${effect.name} ${effect.description} ${effect.tests || ""}`);
      return words.every(word => content.includes(word));
    });
    this.root.querySelector(".gf-s-player-count").textContent = `${visible.length} ${visible.length === 1 ? "efeito" : "efeitos"}`;
    this.root.querySelector(".gf-s-player-grid").innerHTML = visible.map(({ effect, index }) =>
      renderEffectCard(effect, index, this.favorites.has(index))).join("") ||
      `<p class="gf-s-empty">${this.filter === "pinned" && !this.favorites.size ? "Fixe um efeito com a estrela para encontrá-lo aqui." : "Nenhum efeito encontrado. Tente outro termo ou filtro."}</p>`;
  }
}
