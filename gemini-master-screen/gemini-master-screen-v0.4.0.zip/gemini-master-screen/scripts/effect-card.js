export const escapeHTML = value => String(value ?? "").replace(/[&<>"']/g, ch => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
})[ch]);

export function renderEffectCard(effect, index, pinned) {
  return `<article id="gf-s-effect-${index}" class="gf-s-effect" data-effect="${index}">
    <div class="gf-s-effect-top"><span class="gf-s-effect-index">${String(index + 1).padStart(2, "0")}</span>
      <button type="button" class="gf-s-pin ${pinned ? "is-pinned" : ""}" data-pin="${index}" aria-label="${pinned ? "Remover dos fixados" : "Fixar efeito"}: ${escapeHTML(effect.name)}" title="${pinned ? "Remover dos fixados" : "Fixar para consulta rápida"}"><i class="fa-solid fa-star" aria-hidden="true"></i></button></div>
    <h3>${escapeHTML(effect.name)}</h3>
    <p class="gf-s-effect-description">${escapeHTML(effect.description)}</p>
    ${effect.tests ? `<div class="gf-s-effect-test"><span><i class="fa-solid fa-dice-d20" aria-hidden="true"></i> TESTE / RESISTÊNCIA</span><p>${escapeHTML(effect.tests)}</p></div>` : ""}
    <div class="gf-s-tags">${effect.critical ? '<span class="gf-s-tag critical">Crítico / Fumble</span>' : ""}
      ${effect.offense ? '<span class="gf-s-tag offense">Ofensivo</span>' : ""}${effect.defense ? '<span class="gf-s-tag defense">Defensivo</span>' : ""}</div>
  </article>`;
}
