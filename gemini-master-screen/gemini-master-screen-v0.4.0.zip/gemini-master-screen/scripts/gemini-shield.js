import { PlayerEffectsScreen } from "./player-effects.js";

const MODULE_ID = "gemini-master-screen";
let screenApp;

function reportError(error) {
  console.error(`[${MODULE_ID}]`, error);
  ui.notifications.error(`Escudo do Mestre: ${error.message || error}`);
}

class GeminiMasterScreen extends foundry.applications.api.ApplicationV2 {
  static DEFAULT_OPTIONS = {
    id: MODULE_ID,
    classes: ["gemini-master-screen"],
    window: { title: "Escudo do Mestre · Gemini Force", icon: "fa-solid fa-shield-halved", resizable: true },
    position: { width: 1210, height: 790 }
  };

  constructor() {
    super({ window: { title: game.user.isGM ? "Escudo do Mestre · Gemini Force" : "Efeitos Especiais · Gemini Force" } });
  }

  async _renderHTML() {
    this.ScreenClass = game.user.isGM ? (await import("./screen.js")).MasterScreen : PlayerEffectsScreen;
    const root = document.createElement("div");
    root.className = "gf-shield-host";
    return root;
  }

  _replaceHTML(result, content) {
    this.screen?.destroy();
    this.screen = null;
    content.replaceChildren(result);
  }

  _onRender(context, options) {
    super._onRender(context, options);
    const root = this.element.querySelector(".gf-shield-host");
    this.screen = new this.ScreenClass(root, {
      storageKey: `${MODULE_ID}:${game.world.id}:${game.user.id}:favorites:v2`,
      welcomeKey: `${MODULE_ID}:${game.world.id}:${game.user.id}:welcome:v1`,
      welcomeName: game.user.name,
      // Roll locally: the GM can consult a table without publishing a chat message.
      rollDie: async sides => {
        const result = await new Roll(`1d${sides}`).evaluate();
        return result.total;
      }
    });
  }

  async _onClose(options) {
    this.screen?.destroy();
    this.screen = null;
    await super._onClose(options);
  }
}

async function openShield() {
  if (screenApp?.rendered) return screenApp.bringToFront();
  screenApp = new GeminiMasterScreen();
  await screenApp.render({ force: true });
}

Hooks.on("getSceneControlButtons", controls => {
  const gm = game.user.isGM;
  const name = gm ? "geminiMasterScreen" : "geminiEffects";
  controls[name] = {
    name,
    title: gm ? "Escudo do Mestre" : "Efeitos Especiais",
    icon: gm ? "fa-solid fa-shield-halved" : "fa-solid fa-burst",
    order: 76,
    visible: true,
    onChange: (_event, active) => { if (active) void openShield().catch(reportError); },
    tools: {
      openScreen: {
        name: "openScreen",
        title: gm ? "Abrir Escudo do Mestre" : "Consultar Efeitos Especiais",
        icon: gm ? "fa-solid fa-book-open" : "fa-solid fa-burst",
        order: 0,
        button: true,
        visible: true,
        onChange: () => void openShield().catch(reportError)
      }
    }
  };
});

Hooks.once("ready", () => {
  game.modules.get(MODULE_ID).api = Object.freeze({ open: openShield });
});
